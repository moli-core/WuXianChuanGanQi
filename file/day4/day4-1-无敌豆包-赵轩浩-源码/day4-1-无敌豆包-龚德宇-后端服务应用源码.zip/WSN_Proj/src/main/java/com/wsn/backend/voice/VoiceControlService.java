package com.wsn.backend.voice;

import com.wsn.backend.ai.DeviceCommandParser;
import com.wsn.backend.cloud.HuaweiIotClient;

import java.util.LinkedHashMap;
import java.util.Map;

public class VoiceControlService {
    private final XfyunAstClient astClient;
    private final DeviceCommandParser commandParser;
    private final HuaweiIotClient huaweiIotClient;

    public VoiceControlService(XfyunAstClient astClient, DeviceCommandParser commandParser, HuaweiIotClient huaweiIotClient) {
        this.astClient = astClient;
        this.commandParser = commandParser;
        this.huaweiIotClient = huaweiIotClient;
    }

    public Result handle(UploadedFile audio, Map<String, String> fields) throws Exception {
        AudioNormalizer.AudioData audioData = AudioNormalizer.normalize(audio, fields);
        String voiceText = astClient.audioToText(audioData);
        if (voiceText.isBlank()) {
            throw new IllegalArgumentException("语音识别失败，请重新说话");
        }

        Map<String, Object> command = commandParser.parse(voiceText);
        boolean cloudSent = false;
        String cloudError = null;
        if (hasProperties(command)) {
            try {
                huaweiIotClient.sendProperties(command);
                cloudSent = true;
            } catch (Exception ex) {
                cloudError = ex.getMessage();
            }
        }

        return new Result(voiceText, command, cloudSent, cloudError);
    }

    public void sendLed(boolean enabled) throws Exception {
        huaweiIotClient.sendProperties(ledCommand(enabled));
    }

    public static Map<String, Object> ledCommand(boolean enabled) {
        Map<String, Object> properties = new LinkedHashMap<>();
        properties.put("Status_LED", enabled);

        Map<String, Object> command = new LinkedHashMap<>();
        command.put("service_id", "Esp32");
        command.put("properties", properties);
        command.put("intent", enabled ? "turn_on_led" : "turn_off_led");
        return command;
    }

    private boolean hasProperties(Map<String, Object> command) {
        Object properties = command.get("properties");
        return properties instanceof Map<?, ?> map && !map.isEmpty();
    }

    public record Result(String voiceText, Map<String, Object> controlCmd, boolean cloudSent, String cloudError) {
        public Map<String, Object> toMap() {
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("voiceText", voiceText);
            data.put("controlCmd", controlCmd);
            data.put("cloudSent", cloudSent);
            if (cloudError != null && !cloudError.isBlank()) {
                data.put("cloudError", cloudError);
            }
            return data;
        }
    }
}
