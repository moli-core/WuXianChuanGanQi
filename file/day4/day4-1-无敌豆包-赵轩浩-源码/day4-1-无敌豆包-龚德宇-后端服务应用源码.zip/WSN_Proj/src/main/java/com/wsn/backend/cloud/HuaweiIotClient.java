package com.wsn.backend.cloud;

import com.wsn.backend.json.Json;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;

public class HuaweiIotClient {
    private final HttpClient httpClient;
    private final String region;
    private final String iamEndpoint;
    private final String iotdaEndpoint;
    private final String configuredProjectId;
    private final String instanceId;
    private final String deviceId;
    private final String defaultServiceId;
    private final String userName;
    private final String password;
    private final String domainName;

    private String token;
    private Instant tokenExpiresAt = Instant.EPOCH;
    private String tokenProjectId;

    public HuaweiIotClient(
            HttpClient httpClient,
            String region,
            String iamEndpoint,
            String iotdaEndpoint,
            String configuredProjectId,
            String instanceId,
            String deviceId,
            String defaultServiceId,
            String userName,
            String password,
            String domainName
    ) {
        this.httpClient = httpClient;
        this.region = region;
        this.iamEndpoint = trimSlash(iamEndpoint);
        this.iotdaEndpoint = trimSlash(iotdaEndpoint);
        this.configuredProjectId = configuredProjectId;
        this.instanceId = instanceId;
        this.deviceId = deviceId;
        this.defaultServiceId = defaultServiceId == null || defaultServiceId.isBlank() ? "Esp32" : defaultServiceId;
        this.userName = userName;
        this.password = password;
        this.domainName = domainName;
    }

    public static HuaweiIotClient fromEnvironment() {
        return new HuaweiIotClient(
                HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build(),
                env("HW_REGION", "cn-south-1"),
                env("HW_IAM_ENDPOINT", "https://iam.cn-south-1.myhuaweicloud.com"),
                env("HW_IOTDA_ENDPOINT", "https://d1aaeb8e71.st1.iotda-app.cn-south-1.myhuaweicloud.com:443"),
                env("HW_PROJECT_ID", ""),
                env("HW_INSTANCE_ID", ""),
                env("HW_DEVICE_ID", "6a3e4b21c00ccb6d4b6000c5_Esp32_Device"),
                env("HW_SERVICE_ID", "Esp32"),
                env("HW_AUTH_USERNAME", "WSNuser"),
                env("HW_AUTH_PASSWORD", "DzMQqz!Io2AxqsMZ!D"),
                env("HW_AUTH_DOMAIN", "hid_7iskcnx2h6k5gbi")
        );
    }

    public void sendProperties(Map<String, Object> command) throws IOException, InterruptedException {
        assertConfig();
        String serviceId = String.valueOf(command.getOrDefault("service_id", defaultServiceId));
        Object properties = command.get("properties");
        if (!(properties instanceof Map<?, ?> propertyMap) || propertyMap.isEmpty()) {
            return;
        }

        String token = ensureToken(false);
        String url = iotdaEndpoint + "/v5/iot/" + projectId() + "/devices/" + deviceId + "/properties";
        String body = Json.stringify(Map.of(
                "services", List.of(Map.of(
                        "service_id", serviceId,
                        "properties", propertyMap
                ))
        ));

        HttpResponse<String> response = sendPropertyRequest(url, token, body);
        if (response.statusCode() == 401) {
            response = sendPropertyRequest(url, ensureToken(true), body);
        }

        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            throw new IOException("Huawei IoT returned HTTP " + response.statusCode() + ": " + response.body());
        }
    }

    private HttpResponse<String> sendPropertyRequest(String url, String token, String body) throws IOException, InterruptedException {
        HttpRequest.Builder builder = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(20))
                .header("Content-Type", "application/json")
                .header("X-Auth-Token", token)
                .PUT(HttpRequest.BodyPublishers.ofString(body));
        if (instanceId != null && !instanceId.isBlank()) {
            builder.header("Instance-Id", instanceId);
        }
        return httpClient.send(builder.build(), HttpResponse.BodyHandlers.ofString());
    }

    private synchronized String ensureToken(boolean forceRefresh) throws IOException, InterruptedException {
        if (!forceRefresh && token != null && Instant.now().isBefore(tokenExpiresAt.minus(Duration.ofMinutes(5)))) {
            return token;
        }

        String body = Json.stringify(Map.of(
                "auth", Map.of(
                        "identity", Map.of(
                                "methods", List.of("password"),
                                "password", Map.of(
                                        "user", Map.of(
                                                "name", userName,
                                                "password", password,
                                                "domain", Map.of("name", domainName)
                                        )
                                )
                        ),
                        "scope", Map.of("project", Map.of("name", region))
                )
        ));

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(iamEndpoint + "/v3/auth/tokens?nocatalog=true"))
                .timeout(Duration.ofSeconds(20))
                .header("Content-Type", "application/json;charset=utf8")
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            throw new IOException("Huawei IAM returned HTTP " + response.statusCode() + ": " + response.body());
        }

        token = response.headers().firstValue("X-Subject-Token")
                .or(() -> response.headers().firstValue("x-subject-token"))
                .orElseThrow(() -> new IOException("Huawei IAM response has no X-Subject-Token"));
        parseTokenInfo(response.body());
        return token;
    }

    private void parseTokenInfo(String body) {
        Object parsed = Json.parse(body);
        if (!(parsed instanceof Map<?, ?> root) || !(root.get("token") instanceof Map<?, ?> tokenInfo)) {
            return;
        }

        Object expiresAt = tokenInfo.get("expires_at");
        if (expiresAt instanceof String value && !value.isBlank()) {
            tokenExpiresAt = Instant.parse(value);
        } else {
            tokenExpiresAt = Instant.now().plus(Duration.ofHours(12));
        }

        Object project = tokenInfo.get("project");
        if (project instanceof Map<?, ?> projectInfo && projectInfo.get("id") instanceof String id) {
            tokenProjectId = id;
        }
    }

    private String projectId() {
        if (configuredProjectId != null && !configuredProjectId.isBlank()) {
            return configuredProjectId;
        }
        if (tokenProjectId != null && !tokenProjectId.isBlank()) {
            return tokenProjectId;
        }
        throw new IllegalStateException("Missing HW_PROJECT_ID and token project id");
    }

    private void assertConfig() {
        if (userName == null || userName.isBlank() || password == null || password.isBlank() || domainName == null || domainName.isBlank()) {
            throw new IllegalStateException("Missing HW_AUTH_USERNAME, HW_AUTH_PASSWORD or HW_AUTH_DOMAIN");
        }
        if (deviceId == null || deviceId.isBlank()) {
            throw new IllegalStateException("Missing HW_DEVICE_ID");
        }
    }

    private static String trimSlash(String value) {
        String result = value == null ? "" : value.trim();
        while (result.endsWith("/")) {
            result = result.substring(0, result.length() - 1);
        }
        return result;
    }

    private static String env(String name, String fallback) {
        String value = System.getenv(name);
        return value == null || value.isBlank() ? fallback : value;
    }
}
