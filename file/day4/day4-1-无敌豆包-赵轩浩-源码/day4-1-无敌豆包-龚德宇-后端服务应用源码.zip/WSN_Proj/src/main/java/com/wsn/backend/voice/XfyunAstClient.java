package com.wsn.backend.voice;

import com.wsn.backend.json.Json;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpHeaders;
import java.net.http.HttpResponse;
import java.net.http.WebSocket;
import java.net.http.WebSocketHandshakeException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.CompletionException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

public class XfyunAstClient {
    private static final String DEFAULT_ENDPOINT = "wss://office-api-ast-dx.iflyaisol.com/ast/communicate/v1";
    private static final int CHUNK_SIZE = 1280;
    private static final DateTimeFormatter UTC_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssZ");

    private final HttpClient httpClient;
    private final String appId;
    private final String apiKey;
    private final String apiSecret;
    private final String endpoint;

    public XfyunAstClient(HttpClient httpClient, String appId, String apiKey, String apiSecret, String endpoint) {
        this.httpClient = httpClient;
        this.appId = appId == null ? "" : appId.trim();
        this.apiKey = apiKey == null ? "" : apiKey.trim();
        this.apiSecret = apiSecret == null ? "" : apiSecret.trim();
        this.endpoint = endpoint == null || endpoint.isBlank() ? DEFAULT_ENDPOINT : endpoint.trim();
    }

    public static XfyunAstClient fromEnvironment() {
        return new XfyunAstClient(
                HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build(),
                env("XFYUN_APP_ID", "912d7449"),
                env("XFYUN_API_KEY", "0cde2b2e2bf333b1334bf8720d3d4e4f"),
                env("XFYUN_API_SECRET", "Y2Q4ZjZlZDk1Y2VmYThjMTJkYmUzYjQ1"),
                env("XFYUN_AST_ENDPOINT", DEFAULT_ENDPOINT)
        );
    }

    public String audioToText(AudioNormalizer.AudioData audio) throws IOException, InterruptedException {
        if (appId.isBlank() || apiKey.isBlank() || apiSecret.isBlank()) {
            throw new IllegalStateException("Missing XFYUN_APP_ID, XFYUN_API_KEY or XFYUN_API_SECRET");
        }

        String sessionId = UUID.randomUUID().toString();
        SpeechListener listener = new SpeechListener();
        WebSocket webSocket;
        try {
            webSocket = httpClient.newWebSocketBuilder()
                    .connectTimeout(Duration.ofSeconds(10))
                    .buildAsync(URI.create(authenticatedUrl(audio.sampleRate(), sessionId)), listener)
                    .join();
        } catch (CompletionException ex) {
            Throwable cause = ex.getCause();
            if (cause instanceof WebSocketHandshakeException handshakeException) {
                throw new IOException(handshakeMessage(handshakeException), handshakeException);
            }
            throw ex;
        }

        sendAudio(webSocket, audio, sessionId);

        if (!listener.await(60, TimeUnit.SECONDS)) {
            webSocket.abort();
            throw new IOException("Xfyun AST timed out");
        }

        Throwable error = listener.error();
        if (error != null) {
            throw new IOException("Xfyun AST failed: " + error.getMessage(), error);
        }

        String text = listener.text();
        if (text.isBlank()) {
            throw new IOException("Xfyun AST returned empty text");
        }
        return text;
    }

    private void sendAudio(WebSocket webSocket, AudioNormalizer.AudioData audio, String sessionId) throws InterruptedException {
        byte[] pcm = audio.pcmBytes();
        if (pcm.length == 0) {
            throw new IllegalArgumentException("PCM audio is empty");
        }

        int offset = 0;
        while (offset < pcm.length) {
            int size = Math.min(CHUNK_SIZE, pcm.length - offset);
            ByteBuffer chunk = ByteBuffer.wrap(pcm, offset, size);
            offset += size;

            webSocket.sendBinary(chunk, true).join();
            Thread.sleep(40);
        }

        webSocket.sendText(Json.stringify(Map.of("end", true, "sessionId", sessionId)), true).join();
    }

    private String authenticatedUrl(int sampleRate, String sessionId) {
        Map<String, String> params = new TreeMap<>();
        params.put("accessKeyId", apiKey);
        params.put("appId", appId);
        params.put("audio_encode", "pcm_s16le");
        params.put("lang", "autodialect");
        params.put("samplerate", String.valueOf(sampleRate));
        params.put("utc", UTC_FORMATTER.format(ZonedDateTime.now(ZoneId.of("Asia/Shanghai"))));
        params.put("uuid", sessionId);

        String baseString = queryString(params);
        params.put("signature", hmacSha1Base64(apiSecret, baseString));
        return endpoint + "?" + queryString(params);
    }

    private String handshakeMessage(WebSocketHandshakeException ex) {
        HttpResponse<?> response = ex.getResponse();
        if (response == null) {
            return "Xfyun WebSocket handshake failed without response";
        }

        HttpHeaders headers = response.headers();
        return "Xfyun WebSocket handshake failed, HTTP " + response.statusCode() +
                ", server=" + firstHeader(headers, "server") +
                ", requestId=" + firstHeader(headers, "x-request-id") +
                ", traceId=" + firstHeader(headers, "x-trace-id") +
                ", date=" + firstHeader(headers, "date");
    }

    private String firstHeader(HttpHeaders headers, String name) {
        return headers.firstValue(name).orElse("-");
    }

    private static String hmacSha1Base64(String secret, String text) {
        try {
            Mac mac = Mac.getInstance("HmacSHA1");
            mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA1"));
            return Base64.getEncoder().encodeToString(mac.doFinal(text.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException | InvalidKeyException ex) {
            throw new IllegalStateException("Cannot create Xfyun signature", ex);
        }
    }

    private static String queryString(Map<String, String> params) {
        List<String> parts = new ArrayList<>();
        for (Map.Entry<String, String> entry : params.entrySet()) {
            parts.add(urlEncode(entry.getKey()) + "=" + urlEncode(entry.getValue()));
        }
        return String.join("&", parts);
    }

    private static String urlEncode(String value) {
        return URLEncoder.encode(value, StandardCharsets.UTF_8);
    }

    private static String env(String name, String fallback) {
        String value = System.getenv(name);
        return value == null || value.isBlank() ? fallback : value;
    }

    private static final class SpeechListener implements WebSocket.Listener {
        private final CountDownLatch done = new CountDownLatch(1);
        private final StringBuilder text = new StringBuilder();
        private final AtomicReference<Throwable> error = new AtomicReference<>();
        private final StringBuilder currentMessage = new StringBuilder();

        @Override
        public void onOpen(WebSocket webSocket) {
            webSocket.request(1);
        }

        @Override
        public CompletionStage<?> onText(WebSocket webSocket, CharSequence data, boolean last) {
            currentMessage.append(data);
            if (last) {
                handleMessage(currentMessage.toString());
                currentMessage.setLength(0);
            }
            webSocket.request(1);
            return null;
        }

        @Override
        public CompletionStage<?> onClose(WebSocket webSocket, int statusCode, String reason) {
            done.countDown();
            return null;
        }

        @Override
        public void onError(WebSocket webSocket, Throwable error) {
            this.error.compareAndSet(null, error);
            done.countDown();
        }

        private void handleMessage(String message) {
            try {
                Object parsed = Json.parse(message);
                if (!(parsed instanceof Map<?, ?> root)) {
                    return;
                }

                Object actionValue = root.get("action");
                Object resTypeValue = root.get("res_type");
                String action = actionValue == null ? "" : String.valueOf(actionValue);
                String resType = resTypeValue == null ? "" : String.valueOf(resTypeValue);
                Object code = root.get("code");
                boolean errorCode = code instanceof Number number && number.intValue() != 0 ||
                        code instanceof String text && !text.isBlank() && !"0".equals(text);
                if ("error".equals(action) || "frc".equals(resType) || errorCode) {
                    error.compareAndSet(null, new IOException("action=" + action +
                            ", res_type=" + resType +
                            ", code=" + code +
                            ", desc=" + describeError(root)));
                    done.countDown();
                    return;
                }

                String part = extractText(root);
                if (!part.isBlank()) {
                    text.append(part);
                }

                if (isFinal(root)) {
                    done.countDown();
                }
            } catch (RuntimeException ex) {
                error.compareAndSet(null, ex);
                done.countDown();
            }
        }

        private boolean await(long timeout, TimeUnit unit) throws InterruptedException {
            return done.await(timeout, unit);
        }

        private Throwable error() {
            return error.get();
        }

        private String text() {
            return text.toString().trim();
        }

        private boolean isFinal(Map<?, ?> root) {
            Object data = root.get("data");
            if (data instanceof Map<?, ?> dataMap) {
                Object ls = dataMap.get("ls");
                if (ls instanceof Boolean bool) {
                    return bool;
                }
                Object status = dataMap.get("status");
                return status instanceof Number number && number.intValue() == 2;
            }
            return false;
        }

        private String extractText(Map<?, ?> root) {
            Object data = root.get("data");
            if (data instanceof Map<?, ?> dataMap) {
                String ast = extractAstText(dataMap);
                if (!ast.isBlank()) {
                    return ast;
                }

                Object result = dataMap.get("result");
                String iat = extractIatText(result);
                if (!iat.isBlank()) {
                    return iat;
                }

                for (String key : List.of("text", "content", "transcript")) {
                    Object value = dataMap.get(key);
                    if (value instanceof String text) {
                        return text;
                    }
                }
            }

            return recursiveText(root);
        }

        private String describeError(Map<?, ?> root) {
            Object desc = root.get("desc");
            if (desc instanceof String text && !text.isBlank()) {
                return text;
            }

            Object data = root.get("data");
            if (data instanceof Map<?, ?> dataMap) {
                Object dataDesc = dataMap.get("desc");
                if (dataDesc instanceof String text && !text.isBlank()) {
                    return text;
                }
            }

            return Json.stringify(root);
        }

        private String extractAstText(Map<?, ?> dataMap) {
            Object cnValue = dataMap.get("cn");
            if (!(cnValue instanceof Map<?, ?> cnMap)) {
                return "";
            }

            Object stValue = cnMap.get("st");
            if (!(stValue instanceof Map<?, ?> stMap)) {
                return "";
            }

            Object rtValue = stMap.get("rt");
            if (!(rtValue instanceof List<?> rt)) {
                return "";
            }

            StringBuilder builder = new StringBuilder();
            for (Object result : rt) {
                if (!(result instanceof Map<?, ?> resultMap)) {
                    continue;
                }

                Object wsValue = resultMap.get("ws");
                if (!(wsValue instanceof List<?> ws)) {
                    continue;
                }

                appendWords(builder, ws);
            }
            return builder.toString();
        }

        private String extractIatText(Object result) {
            if (!(result instanceof Map<?, ?> resultMap)) {
                return "";
            }

            Object wsValue = resultMap.get("ws");
            if (!(wsValue instanceof List<?> ws)) {
                return "";
            }

            StringBuilder builder = new StringBuilder();
            appendWords(builder, ws);
            return builder.toString();
        }

        private void appendWords(StringBuilder builder, List<?> ws) {
            for (Object segment : ws) {
                if (!(segment instanceof Map<?, ?> segmentMap)) {
                    continue;
                }
                Object cwValue = segmentMap.get("cw");
                if (!(cwValue instanceof List<?> cw) || cw.isEmpty()) {
                    continue;
                }
                Object first = cw.get(0);
                if (first instanceof Map<?, ?> word && word.get("w") instanceof String value) {
                    builder.append(value);
                }
            }
        }

        private String recursiveText(Object value) {
            if (value instanceof Map<?, ?> map) {
                List<String> parts = new ArrayList<>();
                for (Map.Entry<?, ?> entry : map.entrySet()) {
                    String key = String.valueOf(entry.getKey()).toLowerCase(Locale.ROOT);
                    if ((key.equals("text") || key.equals("content") || key.equals("transcript")) && entry.getValue() instanceof String text) {
                        parts.add(text);
                    } else {
                        String nested = recursiveText(entry.getValue());
                        if (!nested.isBlank()) {
                            parts.add(nested);
                        }
                    }
                }
                return String.join("", parts);
            }

            if (value instanceof List<?> list) {
                List<String> parts = new ArrayList<>();
                for (Object item : list) {
                    String nested = recursiveText(item);
                    if (!nested.isBlank()) {
                        parts.add(nested);
                    }
                }
                return String.join("", parts);
            }

            return "";
        }
    }
}
