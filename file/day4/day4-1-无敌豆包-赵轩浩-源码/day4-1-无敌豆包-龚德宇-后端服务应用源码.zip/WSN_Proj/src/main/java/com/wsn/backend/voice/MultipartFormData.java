package com.wsn.backend.voice;

import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

public class MultipartFormData {
    private final Map<String, String> fields = new LinkedHashMap<>();
    private final Map<String, UploadedFile> files = new LinkedHashMap<>();

    public static MultipartFormData parse(HttpExchange exchange) throws IOException {
        String contentType = exchange.getRequestHeaders().getFirst("Content-Type");
        String boundary = boundaryOf(contentType);
        byte[] body = exchange.getRequestBody().readAllBytes();

        MultipartFormData form = new MultipartFormData();
        form.parseBody(body, boundary);
        return form;
    }

    public Map<String, String> fields() {
        return fields;
    }

    public Optional<UploadedFile> file(String name) {
        return Optional.ofNullable(files.get(name));
    }

    private void parseBody(byte[] body, String boundary) {
        byte[] delimiter = ("--" + boundary).getBytes(StandardCharsets.ISO_8859_1);
        int cursor = indexOf(body, delimiter, 0);

        while (cursor >= 0) {
            int partStart = cursor + delimiter.length;
            if (partStart + 1 < body.length && body[partStart] == '-' && body[partStart + 1] == '-') {
                break;
            }

            if (partStart + 1 < body.length && body[partStart] == '\r' && body[partStart + 1] == '\n') {
                partStart += 2;
            }

            int next = indexOf(body, delimiter, partStart);
            if (next < 0) {
                break;
            }

            int partEnd = next;
            if (partEnd >= 2 && body[partEnd - 2] == '\r' && body[partEnd - 1] == '\n') {
                partEnd -= 2;
            }

            parsePart(Arrays.copyOfRange(body, partStart, partEnd));
            cursor = next;
        }
    }

    private void parsePart(byte[] part) {
        byte[] separator = "\r\n\r\n".getBytes(StandardCharsets.ISO_8859_1);
        int separatorIndex = indexOf(part, separator, 0);
        if (separatorIndex < 0) {
            return;
        }

        String headerText = new String(part, 0, separatorIndex, StandardCharsets.ISO_8859_1);
        byte[] content = Arrays.copyOfRange(part, separatorIndex + separator.length, part.length);
        Map<String, String> headers = parseHeaders(headerText);
        String disposition = headers.getOrDefault("content-disposition", "");
        String name = dispositionParameter(disposition, "name");
        if (name == null || name.isBlank()) {
            return;
        }

        String fileName = dispositionParameter(disposition, "filename");
        if (fileName != null) {
            files.put(name, new UploadedFile(name, fileName, headers.getOrDefault("content-type", "application/octet-stream"), content));
        } else {
            fields.put(name, new String(content, StandardCharsets.UTF_8));
        }
    }

    private Map<String, String> parseHeaders(String headerText) {
        Map<String, String> headers = new LinkedHashMap<>();
        for (String line : headerText.split("\r\n")) {
            int colon = line.indexOf(':');
            if (colon > 0) {
                headers.put(line.substring(0, colon).trim().toLowerCase(), line.substring(colon + 1).trim());
            }
        }
        return headers;
    }

    private static String boundaryOf(String contentType) {
        if (contentType == null || !contentType.toLowerCase().contains("multipart/form-data")) {
            throw new IllegalArgumentException("Content-Type must be multipart/form-data");
        }

        for (String part : contentType.split(";")) {
            String item = part.trim();
            if (item.startsWith("boundary=")) {
                String boundary = item.substring("boundary=".length()).trim();
                if (boundary.startsWith("\"") && boundary.endsWith("\"") && boundary.length() >= 2) {
                    boundary = boundary.substring(1, boundary.length() - 1);
                }
                if (!boundary.isBlank()) {
                    return boundary;
                }
            }
        }

        throw new IllegalArgumentException("Missing multipart boundary");
    }

    private static String dispositionParameter(String disposition, String name) {
        String prefix = name + "=";
        for (String part : disposition.split(";")) {
            String item = part.trim();
            if (item.startsWith(prefix)) {
                String value = item.substring(prefix.length()).trim();
                if (value.startsWith("\"") && value.endsWith("\"") && value.length() >= 2) {
                    value = value.substring(1, value.length() - 1);
                }
                return value;
            }
        }
        return null;
    }

    private static int indexOf(byte[] source, byte[] pattern, int from) {
        outer:
        for (int i = Math.max(0, from); i <= source.length - pattern.length; i += 1) {
            for (int j = 0; j < pattern.length; j += 1) {
                if (source[i + j] != pattern[j]) {
                    continue outer;
                }
            }
            return i;
        }
        return -1;
    }
}
