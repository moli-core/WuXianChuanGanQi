package com.wsn.backend.voice;

public record UploadedFile(String fieldName, String fileName, String contentType, byte[] bytes) {
    public boolean isEmpty() {
        return bytes == null || bytes.length == 0;
    }
}
