package com.wsn.backend.voice;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Map;

public final class AudioNormalizer {
    private AudioNormalizer() {
    }

    public static AudioData normalize(UploadedFile file, Map<String, String> fields) {
        if (file.isEmpty()) {
            throw new IllegalArgumentException("Uploaded audio file is empty");
        }

        int sampleRate = intField(fields, "sampleRate", 16000);
        String encoding = fields.getOrDefault("encoding", "").toLowerCase();
        String fileName = file.fileName() == null ? "" : file.fileName().toLowerCase();
        String contentType = file.contentType() == null ? "" : file.contentType().toLowerCase();
        byte[] bytes = file.bytes();

        if (isWave(bytes) || fileName.endsWith(".wav") || contentType.contains("wav")) {
            WavInfo wav = stripWav(bytes);
            return new AudioData(wav.pcmBytes(), wav.sampleRate(), "raw");
        }

        if (encoding.contains("raw") || encoding.contains("pcm") || fileName.endsWith(".pcm") || contentType.contains("pcm")) {
            return new AudioData(bytes, sampleRate, "raw");
        }

        throw new IllegalArgumentException("Only PCM or WAV audio is supported. Please record/upload 16k mono PCM.");
    }

    private static int intField(Map<String, String> fields, String name, int fallback) {
        try {
            return Integer.parseInt(fields.getOrDefault(name, "").trim());
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    private static boolean isWave(byte[] bytes) {
        return bytes.length >= 12 &&
                ascii(bytes, 0, 4).equals("RIFF") &&
                ascii(bytes, 8, 4).equals("WAVE");
    }

    private static WavInfo stripWav(byte[] bytes) {
        if (!isWave(bytes)) {
            throw new IllegalArgumentException("Invalid WAV file");
        }

        int sampleRate = littleEndianInt(bytes, 24);
        int cursor = 12;
        while (cursor + 8 <= bytes.length) {
            String chunkId = ascii(bytes, cursor, 4);
            int chunkSize = littleEndianInt(bytes, cursor + 4);
            int dataStart = cursor + 8;
            if ("data".equals(chunkId)) {
                int dataEnd = Math.min(dataStart + chunkSize, bytes.length);
                return new WavInfo(Arrays.copyOfRange(bytes, dataStart, dataEnd), sampleRate);
            }
            cursor = dataStart + chunkSize + (chunkSize % 2);
        }

        throw new IllegalArgumentException("WAV file has no data chunk");
    }

    private static int littleEndianInt(byte[] bytes, int offset) {
        return (bytes[offset] & 0xff) |
                ((bytes[offset + 1] & 0xff) << 8) |
                ((bytes[offset + 2] & 0xff) << 16) |
                ((bytes[offset + 3] & 0xff) << 24);
    }

    private static String ascii(byte[] bytes, int offset, int length) {
        return new String(bytes, offset, length, StandardCharsets.US_ASCII);
    }

    public record AudioData(byte[] pcmBytes, int sampleRate, String encoding) {
    }

    private record WavInfo(byte[] pcmBytes, int sampleRate) {
    }
}
