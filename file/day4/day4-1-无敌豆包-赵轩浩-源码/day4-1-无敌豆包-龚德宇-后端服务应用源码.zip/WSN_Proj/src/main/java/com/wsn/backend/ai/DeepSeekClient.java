package com.wsn.backend.ai;

import com.wsn.backend.json.Json;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.Map;

public class DeepSeekClient {
    private static final String DEFAULT_BASE_URL = "https://api.deepseek.com";
    private static final String DEFAULT_MODEL = "deepseek-chat";
    private static final String SYSTEM_PROMPT = "你需要完成的工作是组词成句，必要情况下可以适当添加词语。回复我时只需要回复连好的句子。";

    private final HttpClient httpClient;
    private final String apiKey;
    private final String baseUrl;
    private final String model;

    public DeepSeekClient(HttpClient httpClient, String apiKey, String baseUrl, String model) {
        this.httpClient = httpClient;
        this.apiKey = apiKey == null ? "" : apiKey.trim();
        this.baseUrl = stripTrailingSlash(baseUrl == null || baseUrl.isBlank() ? DEFAULT_BASE_URL : baseUrl);
        this.model = model == null || model.isBlank() ? DEFAULT_MODEL : model.trim();
    }

    public static DeepSeekClient fromEnvironment() {
        return new DeepSeekClient(
                HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build(),
                System.getenv("DEEPSEEK_API_KEY"),
                System.getenv("DEEPSEEK_BASE_URL"),
                System.getenv("DEEPSEEK_MODEL")
        );
    }

    public String model() {
        return model;
    }

    public String composeSentence(String text) throws IOException, InterruptedException {
        return chat(SYSTEM_PROMPT, text, 0.2);
    }

    public String chat(String systemPrompt, String userPrompt, double temperature) throws IOException, InterruptedException {
        if (apiKey.isBlank()) {
            throw new IllegalStateException("Missing DEEPSEEK_API_KEY environment variable");
        }

        String payload = Json.stringify(Map.of(
                "model", model,
                "messages", List.of(
                        Map.of("role", "system", "content", systemPrompt),
                        Map.of("role", "user", "content", userPrompt)
                ),
                "stream", false,
                "temperature", temperature
        ));

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(baseUrl + "/chat/completions"))
                .timeout(Duration.ofSeconds(30))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(payload))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            throw new IOException("DeepSeek returned HTTP " + response.statusCode() + ": " + response.body());
        }

        return extractContent(response.body());
    }

    private String extractContent(String responseBody) {
        Object parsed = Json.parse(responseBody);
        if (!(parsed instanceof Map<?, ?> root)) {
            throw new IllegalStateException("Unexpected AI response");
        }

        Object choicesValue = root.get("choices");
        if (!(choicesValue instanceof List<?> choices) || choices.isEmpty()) {
            throw new IllegalStateException("AI response has no choices");
        }

        Object firstChoice = choices.get(0);
        if (!(firstChoice instanceof Map<?, ?> choice)) {
            throw new IllegalStateException("AI response choice is invalid");
        }

        Object messageValue = choice.get("message");
        if (!(messageValue instanceof Map<?, ?> message)) {
            throw new IllegalStateException("AI response message is invalid");
        }

        Object content = message.get("content");
        if (!(content instanceof String text) || text.isBlank()) {
            throw new IllegalStateException("AI response content is empty");
        }

        return text.trim();
    }

    private static String stripTrailingSlash(String value) {
        String result = value.trim();
        while (result.endsWith("/")) {
            result = result.substring(0, result.length() - 1);
        }
        return result;
    }
}
