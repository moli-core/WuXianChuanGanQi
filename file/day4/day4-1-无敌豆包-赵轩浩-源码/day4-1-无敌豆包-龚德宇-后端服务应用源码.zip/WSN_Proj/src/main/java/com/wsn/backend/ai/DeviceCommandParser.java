package com.wsn.backend.ai;

import com.wsn.backend.json.Json;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public class DeviceCommandParser {
    private static final String SYSTEM_PROMPT = """
            你是物联网语音控制指令解析器。把用户语音文本解析为严格 JSON，不要输出解释和 Markdown。
            当前只支持 Esp32 服务的 Status_LED 属性。
            开灯、打开灯、开启 LED、亮灯时输出 true；关灯、关闭灯、熄灯时输出 false。
            输出格式必须是：
            {"service_id":"Esp32","properties":{"Status_LED":true},"intent":"turn_on_led"}
            如果无法判断指令，输出：
            {"service_id":"Esp32","properties":{},"intent":"unknown"}
            """;

    private final DeepSeekClient deepSeekClient;

    public DeviceCommandParser(DeepSeekClient deepSeekClient) {
        this.deepSeekClient = deepSeekClient;
    }

    public Map<String, Object> parse(String voiceText) throws IOException, InterruptedException {
        Map<String, Object> quickCommand = keywordFallback(voiceText);
        if (hasProperties(quickCommand)) {
            return quickCommand;
        }

        try {
            String answer = deepSeekClient.chat(SYSTEM_PROMPT, voiceText, 0.0);
            return normalize(answer);
        } catch (Exception ex) {
            return quickCommand;
        }
    }

    private Map<String, Object> normalize(String answer) {
        String json = extractJson(answer);
        Object parsed = Json.parse(json);
        if (!(parsed instanceof Map<?, ?> value)) {
            throw new IllegalArgumentException("AI command is not a JSON object");
        }

        Map<String, Object> command = new LinkedHashMap<>();
        Object serviceId = value.get("service_id");
        command.put("service_id", serviceId == null ? "Esp32" : String.valueOf(serviceId));

        Object propertiesValue = value.get("properties");
        Map<String, Object> properties = new LinkedHashMap<>();
        if (propertiesValue instanceof Map<?, ?> rawProperties) {
            Object led = rawProperties.get("Status_LED");
            Boolean normalizedLed = normalizeBoolean(led);
            if (normalizedLed != null) {
                properties.put("Status_LED", normalizedLed);
            }
        }

        command.put("properties", properties);
        Object intent = value.get("intent");
        command.put("intent", intent == null ? (properties.isEmpty() ? "unknown" : "control_led") : String.valueOf(intent));
        return command;
    }

    private Map<String, Object> keywordFallback(String voiceText) {
        String text = voiceText == null ? "" : voiceText.toLowerCase(Locale.ROOT);
        Map<String, Object> properties = new LinkedHashMap<>();
        String intent = "unknown";

        if (text.contains("打开") || text.contains("开启") || text.contains("开灯") || text.contains("亮灯") || text.contains("on")) {
            properties.put("Status_LED", true);
            intent = "turn_on_led";
        } else if (text.contains("关闭") || text.contains("关灯") || text.contains("熄灯") || text.contains("off")) {
            properties.put("Status_LED", false);
            intent = "turn_off_led";
        }

        Map<String, Object> command = new LinkedHashMap<>();
        command.put("service_id", "Esp32");
        command.put("properties", properties);
        command.put("intent", intent);
        return command;
    }

    private boolean hasProperties(Map<String, Object> command) {
        Object properties = command.get("properties");
        return properties instanceof Map<?, ?> map && !map.isEmpty();
    }

    private String extractJson(String answer) {
        int start = answer.indexOf('{');
        int end = answer.lastIndexOf('}');
        if (start < 0 || end < start) {
            throw new IllegalArgumentException("AI command response has no JSON object");
        }
        return answer.substring(start, end + 1);
    }

    private Boolean normalizeBoolean(Object value) {
        if (value instanceof Boolean bool) {
            return bool;
        }
        if (value instanceof Number number) {
            return number.intValue() != 0;
        }
        if (value instanceof String text) {
            String normalized = text.toLowerCase(Locale.ROOT);
            if (normalized.equals("true") || normalized.equals("on") || normalized.equals("1")) {
                return true;
            }
            if (normalized.equals("false") || normalized.equals("off") || normalized.equals("0")) {
                return false;
            }
        }
        return null;
    }
}
