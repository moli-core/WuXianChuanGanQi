package com.wsn.backend;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import com.wsn.backend.ai.DeviceCommandParser;
import com.wsn.backend.ai.DeepSeekClient;
import com.wsn.backend.cloud.HuaweiIotClient;
import com.wsn.backend.json.Json;
import com.wsn.backend.voice.MultipartFormData;
import com.wsn.backend.voice.UploadedFile;
import com.wsn.backend.voice.VoiceControlService;
import com.wsn.backend.voice.XfyunAstClient;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;

public class AiBackendServer {
    private final DeepSeekClient deepSeekClient;
    private final VoiceControlService voiceControlService;

    public AiBackendServer(DeepSeekClient deepSeekClient, VoiceControlService voiceControlService) {
        this.deepSeekClient = deepSeekClient;
        this.voiceControlService = voiceControlService;
    }

    public static void main(String[] args) throws IOException {
        int port = intEnv("SERVER_PORT", 8080);
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        DeepSeekClient deepSeekClient = DeepSeekClient.fromEnvironment();
        AiBackendServer app = new AiBackendServer(
                deepSeekClient,
                new VoiceControlService(
                        XfyunAstClient.fromEnvironment(),
                        new DeviceCommandParser(deepSeekClient),
                        HuaweiIotClient.fromEnvironment()
                )
        );

        server.createContext("/health", app::handleHealth);
        server.createContext("/api/ai/compose", app::handleCompose);
        server.createContext("/api/voice/light", app::handleVoiceLight);
        server.createContext("/api/device/light", app::handleDeviceLight);
        server.setExecutor(Executors.newCachedThreadPool());
        server.start();

        System.out.printf("WSN backend started at http://localhost:%d%n", port);
    }

    private void handleHealth(HttpExchange exchange) throws IOException {
        if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
            writeJson(exchange, 405, Map.of("error", "Method not allowed"));
            return;
        }

        writeJson(exchange, 200, Map.of("status", "ok"));
    }

    private void handleCompose(HttpExchange exchange) throws IOException {
        addCorsHeaders(exchange.getResponseHeaders());

        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }

        if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            writeJson(exchange, 405, Map.of("error", "Method not allowed"));
            return;
        }

        try {
            Map<String, Object> request = readJsonObject(exchange);
            String input = readInputText(request);
            String result = deepSeekClient.composeSentence(input);

            writeJson(exchange, 200, Map.of(
                    "input", input,
                    "result", result,
                    "model", deepSeekClient.model()
            ));
        } catch (IllegalArgumentException ex) {
            writeJson(exchange, 400, Map.of("error", ex.getMessage()));
        } catch (IllegalStateException ex) {
            writeJson(exchange, 503, Map.of("error", ex.getMessage()));
        } catch (Exception ex) {
            writeJson(exchange, 502, Map.of("error", "AI service request failed", "detail", ex.getMessage()));
        }
    }

    private void handleVoiceLight(HttpExchange exchange) throws IOException {
        addCorsHeaders(exchange.getResponseHeaders());

        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }

        if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            writeJson(exchange, 405, Map.of("code", 405, "msg", "Method not allowed"));
            return;
        }

        try {
            MultipartFormData form = MultipartFormData.parse(exchange);
            UploadedFile audio = form.file("audio")
                    .orElseThrow(() -> new IllegalArgumentException("Missing multipart file field: audio"));
            VoiceControlService.Result result = voiceControlService.handle(audio, form.fields());

            writeJson(exchange, 200, Map.of(
                    "code", 200,
                    "msg", "success",
                    "data", result.toMap()
            ));
        } catch (IllegalArgumentException ex) {
            writeJson(exchange, 400, Map.of("code", 400, "msg", ex.getMessage()));
        } catch (Exception ex) {
            writeJson(exchange, 500, Map.of("code", 500, "msg", "服务异常：" + ex.getMessage()));
        }
    }

    private void handleDeviceLight(HttpExchange exchange) throws IOException {
        addCorsHeaders(exchange.getResponseHeaders());

        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }

        if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            writeJson(exchange, 405, Map.of("code", 405, "msg", "Method not allowed"));
            return;
        }

        try {
            Map<String, Object> request = readJsonObject(exchange);
            Object enabledValue = request.get("enabled");
            if (!(enabledValue instanceof Boolean enabled)) {
                throw new IllegalArgumentException("Request field enabled must be boolean");
            }

            voiceControlService.sendLed(enabled);
            writeJson(exchange, 200, Map.of(
                    "code", 200,
                    "msg", "success",
                    "data", Map.of(
                            "controlCmd", VoiceControlService.ledCommand(enabled),
                            "cloudSent", true
                    )
            ));
        } catch (IllegalArgumentException ex) {
            writeJson(exchange, 400, Map.of("code", 400, "msg", ex.getMessage()));
        } catch (Exception ex) {
            writeJson(exchange, 500, Map.of("code", 500, "msg", "服务异常：" + ex.getMessage()));
        }
    }

    private Map<String, Object> readJsonObject(HttpExchange exchange) throws IOException {
        String body;
        try (InputStream input = exchange.getRequestBody()) {
            body = new String(input.readAllBytes(), StandardCharsets.UTF_8);
        }

        Object value = Json.parse(body);
        if (!(value instanceof Map<?, ?> map)) {
            throw new IllegalArgumentException("Request body must be a JSON object");
        }

        @SuppressWarnings("unchecked")
        Map<String, Object> result = (Map<String, Object>) map;
        return result;
    }

    private String readInputText(Map<String, Object> request) {
        Object text = request.get("text");
        if (text instanceof String value && !value.isBlank()) {
            return value.trim();
        }

        Object words = request.get("words");
        if (words instanceof List<?> values && !values.isEmpty()) {
            String joined = values.stream()
                    .map(String::valueOf)
                    .map(String::trim)
                    .filter(value -> !value.isEmpty())
                    .reduce((left, right) -> left + " " + right)
                    .orElse("");

            if (!joined.isBlank()) {
                return joined;
            }
        }

        throw new IllegalArgumentException("Provide a non-empty text string or words array");
    }

    private static void writeJson(HttpExchange exchange, int status, Object value) throws IOException {
        byte[] payload = Json.stringify(value).getBytes(StandardCharsets.UTF_8);
        Headers headers = exchange.getResponseHeaders();
        addCorsHeaders(headers);
        headers.set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(status, payload.length);

        try (OutputStream output = exchange.getResponseBody()) {
            output.write(payload);
        }
    }

    private static void addCorsHeaders(Headers headers) {
        headers.set("Access-Control-Allow-Origin", "*");
        headers.set("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
        headers.set("Access-Control-Allow-Headers", "Content-Type,Authorization");
    }

    private static int intEnv(String name, int fallback) {
        String value = System.getenv(name);
        if (value == null || value.isBlank()) {
            return fallback;
        }

        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }
}
