# WSN Backend

This backend exposes the DeepSeek sentence-composition feature migrated from `dp.py`, and the voice-control chain:

1. receive PCM/WAV audio from the WeChat mini program or ESP32;
2. transcribe audio through iFlytek AST WebSocket;
3. parse the transcript into a standard IoT command through DeepSeek;
4. send the command to Huawei IoTDA so ESP32 can control peripherals through MQTT.

## Run

Set your DeepSeek API key first:

```powershell
$env:DEEPSEEK_API_KEY="your_api_key"
```

The iFlytek and Huawei IoTDA defaults are already aligned with the current project. You can override them through environment variables when needed:

```powershell
$env:XFYUN_APP_ID="your_app_id"
$env:XFYUN_API_KEY="your_api_key"
$env:XFYUN_API_SECRET="your_api_secret"
$env:XFYUN_AST_ENDPOINT="wss://office-api-ast-dx.iflyaisol.com/"

$env:HW_REGION="cn-south-1"
$env:HW_IAM_ENDPOINT="https://iam.cn-south-1.myhuaweicloud.com"
$env:HW_IOTDA_ENDPOINT="https://your-iotda-endpoint:443"
$env:HW_DEVICE_ID="your_device_id"
$env:HW_SERVICE_ID="Esp32"
$env:HW_AUTH_USERNAME="your_iam_user"
$env:HW_AUTH_PASSWORD="your_iam_password"
$env:HW_AUTH_DOMAIN="your_account_name"
```

Compile and run with the JDK:

```powershell
javac -encoding UTF-8 -d out (Get-ChildItem -Recurse src\main\java\*.java)
java -cp out com.wsn.backend.AiBackendServer
```

The service listens on `http://localhost:8080` by default. Override the port with `SERVER_PORT`.

## API

Health check:

```http
GET /health
```

Compose words into a sentence:

```http
POST /api/ai/compose
Content-Type: application/json

{"text":"电风扇 打开 有点热"}
```

You can also send an array:

```json
{"words":["电风扇","打开","有点热"]}
```

Response:

```json
{"input":"电风扇 打开 有点热","result":"有点热，请打开电风扇。","model":"deepseek-chat"}
```

Optional environment variables:

- `DEEPSEEK_BASE_URL`, default `https://api.deepseek.com`
- `DEEPSEEK_MODEL`, default `deepseek-chat`
- `SERVER_PORT`, default `8080`

## Voice Control API

```http
POST /api/voice/light
Content-Type: multipart/form-data

audio=<16k mono PCM or WAV>
sampleRate=16000
channels=1
encoding=pcm
```

Response:

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "voiceText": "打开灯",
    "controlCmd": {
      "service_id": "Esp32",
      "properties": {
        "Status_LED": true
      },
      "intent": "turn_on_led"
    },
    "cloudSent": true
  }
}
```

The mini program and ESP32 now upload PCM directly, so the backend does not need an external MP3 decoder.
