#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
 
// OLED配置
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
 
// WiFi热点信息（纯英文2.4G热点）
const char* ssid     = "Tony";
const char* password = "zcaf7542";
 
// Web服务器端口80
WebServer server(80);
 
// LED引脚
const int ledPin = 2;
bool ledState = false;
 
// 网页首页HTML
String htmlPage = R"HTML(
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>ESP32 Web控制</title>
<style>
button{font-size:22px;padding:10px 30px;margin:10px;}
</style>
</head>
<body align="center">
<h2>ESP32 LED远程控制</h2>
<a href="/led/on"><button>打开LED</button></a>
<a href="/led/off"><button>关闭LED</button></a>
<p>当前LED状态:%STATUS%</p>
</body>
</html>
)HTML";
 
// 首页回调
void handleRoot() {
  String page = htmlPage;
  if(ledState) page.replace("%STATUS%", "点亮");
  else page.replace("%STATUS%", "熄灭");
  server.send(200, "text/html", page);
}
 
// LED开
void ledOn() {
  ledState = true;
  digitalWrite(ledPin, HIGH);
  handleRoot();
}
 
// LED关
void ledOff() {
  ledState = false;
  digitalWrite(ledPin, LOW);
  handleRoot();
}
 
// 404页面
void handleNotFound() {
  server.send(404, "text/plain", "页面不存在");
}
 
void setup() {
  Serial.begin(115200);
  pinMode(ledPin, OUTPUT);
  digitalWrite(ledPin, LOW);
 
  // OLED初始化
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED初始化失败");
    while(1);
  }
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
 
  // 连接WiFi
  display.setCursor(0,0);
  display.println("Connect Hotspot...");
  display.display();
 
  WiFi.begin(ssid, password);
  while(WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
 
  // WiFi连上，OLED打印IP地址
  display.clearDisplay();
  display.println("WiFi Connected!");
  display.print("Web IP:");
  display.println(WiFi.localIP());
  display.println("浏览器访问该IP");
  display.display();
 
  Serial.print("Web Server Addr:");
  Serial.println(WiFi.localIP());
 
  // 绑定网页路由
  server.on("/", handleRoot);
  server.on("/led/on", ledOn);
  server.on("/led/off", ledOff);
  server.onNotFound(handleNotFound);
 
  // 启动web服务
  server.begin();
  Serial.println("Web服务已启动");
}
 
void loop() {
  server.handleClient(); // 持续处理浏览器请求
}

