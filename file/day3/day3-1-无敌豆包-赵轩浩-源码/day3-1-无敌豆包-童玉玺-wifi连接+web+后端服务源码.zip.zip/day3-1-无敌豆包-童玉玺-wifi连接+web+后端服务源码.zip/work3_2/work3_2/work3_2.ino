#include <WiFi.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
 
// OLED参数配置
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET_PIN -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET_PIN);
 
// 填入你的手机2.4G热点名称、密码
const char* wifi_ssid = "Tony";
const char* wifi_pwd  = "zcaf7542";
 
void setup()
{
// 初始化串口通信，波特率 115200
  Serial.begin(115200);
 
  // OLED初始化
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C))
  {
    Serial.println("OLED初始化失败，检查接线或I2C地址");
    while(1);
  }
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
 
  // 屏幕提示正在连接手机热点
  display.setCursor(0, 0);
  display.println("Connect Phone Hotspot");
  display.display();
 
  // 发起WiFi连接
  WiFi.begin(wifi_ssid, wifi_pwd);
  while(WiFi.status() != WL_CONNECTED)
  {
    delay(500);
    Serial.print(".");
  }
 
  // 连接成功，刷新屏幕信息
  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("WiFi Connected OK");
  display.print("Local IP:");
  display.println(WiFi.localIP());
  display.print("Signal:");
  display.print(WiFi.RSSI());
  display.println(" dBm");
  display.display();
 
  Serial.println("\n连接成功，设备IP：");
  Serial.println(WiFi.localIP());
}
 
void loop()
{
  // 掉线自动重连逻辑
  if(WiFi.status() != WL_CONNECTED)
  {
    display.clearDisplay();
    display.println("WiFi Disconnected");
    display.println("Reconnecting...");
    display.display();
    WiFi.reconnect();
    delay(1000);
  }
  delay(1000);
}

