#include <WiFi.h>
#include <HTTPClient.h>
#include <WebServer.h>
#include <ArduinoJson.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
 
// ========== 只需修改这几项配置 ==========
const char* ssid        = "Tony";
const char* password    = "zcaf7542";
// SpringBoot后端电脑局域网IP + 端口
const char* springIp    = "192.168.126.217";
const int springPort    = 8082;
const char* apiUri      = "/frontweather/getWeatherJson";
 
#define OLED_SDA 21
#define OLED_SCL 22
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET    -1
// ====================================
 
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
WebServer server(80);
HTTPClient httpClient;
 
int temp = -999, humidity = -999;
String updateTime = "";
String weatherTxt = "";
unsigned long lastFetchTime = 0;
const unsigned long fetchInterval = 30000;
 
// ESP32自带网页展示
void handleRoot() {
  String html = "<!DOCTYPE HTML>";
  html += "<html><head>";
  html += "<meta charset='utf-8'>";
  html += "<title>ESP32天气监测</title>";
  html += "<style>body{font-size:22px;margin:40px;} .box{border:1px solid #ccc;padding:20px;width:420px}</style>";
  html += "</head><body>";
  html += "<div class='box'>";
  if(temp == -999 || humidity == -999){
    html += "<h3>天气数据获取失败</h3>";
  }else{
    html += "<h3>实时天气</h3>";
    html += "<p>天气状况：" + weatherTxt + "</p>";
    html += "<p>温度：" + String(temp) + " ℃</p>";
    html += "<p>湿度：" + String(humidity) + " %</p>";
    html += "<p>更新时间：" + updateTime + "</p>";
  }
  html += "</div></body></html>";
  server.send(200, "text/html", html);
}
 
// 访问SpringBoot后端接口获取天气JSON
void fetchWeather() {
  if(WiFi.status() != WL_CONNECTED){
    Serial.println("WiFi离线,跳过请求");
    temp = -999; humidity = -999;
    return;
  }
  if(httpClient.connected()) httpClient.end();
 
  // 拼接后端HTTP接口地址（局域网HTTP，无需SSL）
  String url = "http://" + String(springIp) + ":" + String(springPort) + String(apiUri);
  Serial.println("请求后端URL: " + url);
 
  bool ok = httpClient.begin(url.c_str());
  if(!ok){
    Serial.println("http.begin初始化失败");
    httpClient.end();
    temp = -999; humidity = -999;
    return;
  }
 
  int httpCode = httpClient.GET();
  Serial.print("HTTP返回码:");
  Serial.println(httpCode);
  if(httpCode != HTTP_CODE_OK){
    Serial.print("GET错误:");
    Serial.println(httpClient.errorToString(httpCode));
    httpClient.end();
    temp = -999; humidity = -999;
    return;
  }
 
  String payload = httpClient.getString();
  Serial.println("后端返回JSON:\n" + payload);
 
  StaticJsonDocument<768> doc;
  DeserializationError err = deserializeJson(doc, payload);
  if(err){
    Serial.print("JSON解析失败：");
    Serial.println(err.c_str());
    httpClient.end();
    temp = -999; humidity = -999;
    return;
  }
 
  // 解析后端返回的JSON结构
  String code = doc["code"].as<String>();
  if(code != "200"){
    Serial.println("后端接口返回异常");
    temp = -999; humidity = -999;
    updateTime = ""; weatherTxt = "";
    httpClient.end();
    return;
  }
 
  temp        = doc["now"]["temp"].as<int>();
  humidity    = doc["now"]["humidity"].as<int>();
  weatherTxt  = doc["now"]["text"].as<String>();
  updateTime  = doc["updateTime"].as<String>();
 
  Serial.print("温度：");Serial.println(temp);
  Serial.print("湿度：");Serial.println(humidity);
  Serial.print("天气：");Serial.println(weatherTxt);
  httpClient.end();
}
 
// OLED屏幕刷新
void oledShow() {
  display.clearDisplay();
  display.setCursor(0, 0);
 
  if(temp == -999 || humidity == -999) {
    display.setTextSize(2);
    display.println("DATA ERROR");
  } else {
    display.setTextSize(2);
    display.print("Temp: ");
    display.print(temp);
    display.println(" C");
 
    display.setCursor(0, 24);
    display.print("Hum:  ");
    display.print(humidity);
    display.println(" %");
 
    display.setTextSize(1);
    display.setCursor(0, 40);
    display.print(weatherTxt);
    display.print(" ");
    if(updateTime.length() >= 16) {
      display.print(updateTime.substring(5, 16));
    } else {
      display.print(updateTime);
    }
  }
  display.display();
}
 
void setup() {
  Serial.begin(115200);
  Wire.begin(OLED_SDA, OLED_SCL);
 
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED初始化失败");
    while(1) delay(100);
  }
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(0,0);
  display.println("WiFi Connecting...");
  display.display();
 
  WiFi.begin(ssid, password);
  int cnt = 0;
  while(WiFi.status() != WL_CONNECTED && cnt < 30) {
    delay(500);
    cnt++;
  }
 
  if(WiFi.status() == WL_CONNECTED) {
    Serial.print("ESP32 IP: ");
    Serial.println(WiFi.localIP());
    display.clearDisplay();
    display.println("WiFi OK");
    display.println(WiFi.localIP().toString());
    display.display();
    delay(2000);
 
    server.on("/", handleRoot);
    server.begin();
    Serial.println("ESP32 Web服务已启动");
  } else {
    display.clearDisplay();
    display.println("WiFi FAIL");
    display.display();
  }
}
 
void loop() {
  server.handleClient();
 
  if(millis() - lastFetchTime >= fetchInterval) {
    fetchWeather();
    oledShow();
    lastFetchTime = millis();
  }
}

