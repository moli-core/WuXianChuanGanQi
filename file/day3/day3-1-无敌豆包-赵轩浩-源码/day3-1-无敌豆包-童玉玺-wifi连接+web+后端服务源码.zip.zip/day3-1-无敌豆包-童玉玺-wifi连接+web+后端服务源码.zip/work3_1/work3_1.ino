#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
 
// OLED分辨率 128*64，常用0.96寸
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
 
// I2C地址，绝大多数模块 0x3C 或 0x3D
#define OLED_RESET     -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
 
void setup() {
  Serial.begin(115200);
 
  // 初始化OLED
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("OLED初始化失败，检查接线/地址"));
    for(;;); // 卡死等待排查
  }
  display.clearDisplay();   // 清屏
  display.setTextSize(1);   // 字体大小
  display.setTextColor(WHITE);
 
  // 多行文字打印
  display.setCursor(0, 0);
  display.println("ESP32 OLED Test");
  display.println("SDA:GPIO21");
  display.println("SCL:GPIO22");
  display.println("I2C OK!");
 
  // 画方框演示图形
  display.drawRect(80,30,40,20,WHITE);
 
  display.display(); // 刷新屏幕
}
 
void loop() {
  // 静态显示无需循环操作
}

