/*
 * ESP32 WiFi + Web + LED 控制
 * Velxio 仿真版
 * 接线: GPIO 2 → 电阻(220Ω) → LED → GND
 */

#include <WiFi.h>
#include <WebServer.h>

// Velxio 中 WiFi 可用任意 SSID，QEMU 模拟网络
const char* ssid     = "VelxioNet";
const char* password = "12345678";

#define LED_PIN 2
WebServer server(80);

String wTemp = "26", wText = "晴", wHum = "45", wCity = "北京";
unsigned long lastTick = 0;

// 函数前置声明 (ESP-IDF 编译必需)
void updateWeather();
void handleRoot();
void handleLEDOn();
void handleLEDOff();
void handleLEDStatus();
void handleWeather();

// ==================== SETUP ====================
void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  Serial.println("\n=== ESP32 WiFi+Web 启动 ===");

  // 连接 WiFi
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);
  Serial.print("连接 WiFi");
  int retry = 0;
  while (WiFi.status() != WL_CONNECTED && retry < 20) {
    delay(500); Serial.print("."); retry++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi 已连接!");
    Serial.print("IP地址: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\nWiFi 未连接，启动离线模式");
  }

  // 注册路由
  server.on("/",           handleRoot);
  server.on("/led/on",     handleLEDOn);
  server.on("/led/off",    handleLEDOff);
  server.on("/led/status", handleLEDStatus);
  server.on("/weather",    handleWeather);

  server.begin();
  Serial.println("Web服务器已启动 (端口80)");
  Serial.println("在浏览器输入ESP32的IP地址即可访问");
}

// ==================== LOOP ====================
void loop() {
  server.handleClient();

  if (millis() - lastTick > 8000) {
    updateWeather();
    lastTick = millis();
  }
}

// ==================== 天气模拟更新 ====================
void updateWeather() {
  const char* t[] = {"22","24","26","28","30","25","27","23","29"};
  const char* x[] = {"晴","多云","阴","小雨","晴间多云","多云转晴"};
  const char* h[] = {"35","42","48","55","60","45","52","50","38"};
  int i = (millis() / 8000) % 9;
  wTemp = t[i];
  wText = x[i % 6];
  wHum  = h[i];
  Serial.printf("[天气] %s°C %s 湿度%s%%\n", wTemp.c_str(), wText.c_str(), wHum.c_str());
}

// ==================== LED 控制 ====================
void handleLEDOn() {
  digitalWrite(LED_PIN, HIGH);
  Serial.println("LED -> ON");
  server.send(200, "text/plain", "ON");
}

void handleLEDOff() {
  digitalWrite(LED_PIN, LOW);
  Serial.println("LED -> OFF");
  server.send(200, "text/plain", "OFF");
}

void handleLEDStatus() {
  server.send(200, "text/plain", String(digitalRead(LED_PIN)));
}

// ==================== 天气接口 ====================
void handleWeather() {
  String json = "{";
  json += "\"temp\":\""     + wTemp + "\",";
  json += "\"humidity\":\"" + wHum  + "\",";
  json += "\"text\":\""     + wText + "\",";
  json += "\"city\":\""     + wCity + "\"";
  json += "}";
  server.send(200, "application/json", json);
}

// ==================== 网页 ====================
void handleRoot() {
  String h;
  h += F("<!DOCTYPE html><html lang='zh-CN'><head><meta charset='UTF-8'>");
  h += F("<meta name='viewport' content='width=device-width,initial-scale=1'>");
  h += F("<title>ESP32智能面板</title>");
  h += F("<style>");
  h += F("*{margin:0;padding:0;box-sizing:border-box}");
  h += F("body{font-family:sans-serif;background:linear-gradient(135deg,#1a1a3e,#0d0d2b);");
  h += F("min-height:100vh;display:flex;justify-content:center;align-items:center;padding:15px}");
  h += F(".c{background:#fff;border-radius:18px;padding:25px;max-width:400px;width:100%}");
  h += F("h1{text-align:center;color:#333;font-size:22px}");
  h += F(".sub{text-align:center;color:#888;font-size:12px;margin-bottom:14px}");
  h += F(".s{background:#f8f9fa;border-radius:12px;padding:16px;margin-bottom:14px}");
  h += F(".st{font-size:15px;font-weight:700;color:#555;margin-bottom:12px}");
  h += F(".led-box{display:flex;align-items:center;justify-content:center;gap:10px;margin-bottom:12px}");
  h += F(".led{width:32px;height:32px;border-radius:50%;background:#ccc;transition:.3s}");
  h += F(".led.on{background:#ffeb3b;box-shadow:0 0 25px #ffeb3b}");
  h += F(".btns{display:flex;gap:10px;justify-content:center}");
  h += F(".btn{padding:12px 32px;border:none;border-radius:8px;font-size:15px;font-weight:700;cursor:pointer;color:#fff}");
  h += F(".btn-on{background:#4caf50}.btn-off{background:#f44336}");
  h += F(".wg{display:grid;grid-template-columns:1fr 1fr;gap:10px}");
  h += F(".wi{text-align:center;padding:12px;background:#fff;border-radius:8px}");
  h += F(".wv{font-size:26px;font-weight:700;color:#333}");
  h += F(".wl{font-size:11px;color:#999;margin-top:3px}");
  h += F(".rf{width:100%;margin-top:10px;padding:10px;background:#2196F3;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer}");
  h += F(".badge{background:#ff9800;color:#fff;padding:2px 8px;border-radius:10px;font-size:10px}");
  h += F("</style></head><body><div class='c'>");
  h += F("<h1>ESP32智能面板</h1>");
  h += F("<p class='sub'>WiFi+Web+后端  |  物联网工程实训</p>");
  h += F("<div style='text-align:center'><span class='badge'>仿真演示</span></div>");

  // LED区域
  h += F("<div class='s'><div class='st'>LED 远程控制</div>");
  h += F("<div class='led-box'><span>状态:</span>");
  h += F("<div class='led' id='ld'></div><span id='ls'>检测中</span></div>");
  h += F("<div class='btns'>");
  h += F("<button class='btn btn-on' onclick='ctl(1)'>开灯</button>");
  h += F("<button class='btn btn-off' onclick='ctl(0)'>关灯</button>");
  h += F("</div></div>");

  // 天气区域
  h += F("<div class='s'><div class='st'>天气预报</div>");
  h += F("<div class='wg'>");
  h += F("<div class='wi'><div class='wv' id='tp'>--</div><div class='wl'>温度(C)</div></div>");
  h += F("<div class='wi'><div class='wv' id='hm'>--</div><div class='wl'>湿度(%)</div></div>");
  h += F("<div class='wi'><div class='wv' id='tx'>--</div><div class='wl'>天气</div></div>");
  h += F("<div class='wi'><div class='wv' id='ct'>北京</div><div class='wl'>城市</div></div>");
  h += F("</div>");
  h += F("<button class='rf' onclick='rf()'>刷新天气</button>");
  h += F("</div></div>");

  // JS
  h += F("<script>");
  h += F("function ctl(o){fetch('/led/'+(o?'on':'off')).then(()=>{document.getElementById('ld').className='led'+(o?' on':'');document.getElementById('ls').textContent=o?'已开':'已关'})}");
  h += F("function rf(){fetch('/weather').then(r=>r.json()).then(j=>{document.getElementById('tp').textContent=j.temp+'C';document.getElementById('hm').textContent=j.humidity+'%';document.getElementById('tx').textContent=j.text;document.getElementById('ct').textContent=j.city})}");
  h += F("fetch('/led/status').then(r=>r.text()).then(v=>{document.getElementById('ld').className='led'+(v=='1'?' on':'');document.getElementById('ls').textContent=v=='1'?'已开':'已关'});rf();");
  h += F("</script></body></html>");

  server.send(200, "text/html", h);
}
