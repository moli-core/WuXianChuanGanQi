"""
ESP32 本地仿真器
模拟: WiFi连接 + Web服务器 + LED控制 + 天气数据
运行: python esp32-simulator.py
访问: http://localhost:8081
"""
import http.server
import json
import time
import random
import threading
import urllib.request
import sys
import os

# ==================== 配置 ====================
SIM_PORT = 8081          # 仿真 ESP32 Web 端口
BACKEND_URL = "http://localhost:8080"  # SpringBoot 后端

LED_STATE = False        # LED 初始关闭
weather_cache = {
    "temp": "26", "text": "晴", "humidity": "45", "city": "北京"
}

# ==================== 串口模拟 ====================
def serial_print(msg):
    """模拟 ESP32 串口输出"""
    t = time.strftime("%H:%M:%S")
    print(f"[{t}] {msg}")

# ==================== 天气更新 (从后端获取) ====================
def update_weather():
    global weather_cache
    try:
        url = f"{BACKEND_URL}/api/weather/now?city={weather_cache['city']}"
        req = urllib.request.Request(url)
        resp = urllib.request.urlopen(req, timeout=5)
        data = json.loads(resp.read())
        if data.get("code") == 200 and data.get("data"):
            d = data["data"]
            weather_cache = {
                "temp": d.get("temp", "26"),
                "text": d.get("text", "晴"),
                "humidity": d.get("humidity", "48"),
                "city": d.get("city", "北京")
            }
            serial_print(f"[天气] 从后端获取: {weather_cache['temp']}°C {weather_cache['text']} {weather_cache['humidity']}%")
            return True
    except Exception as e:
        # 后端不可用，用模拟数据
        temps = ["22","24","26","28","30","25","27"]
        texts = ["晴","多云","阴","小雨","晴间多云"]
        hums  = ["35","42","48","55","60","45","52"]
        i = random.randint(0, 6)
        weather_cache = {
            "temp": temps[i], "text": texts[i % 5],
            "humidity": hums[i], "city": weather_cache["city"]
        }
        serial_print(f"[天气] 模拟数据: {weather_cache['temp']}°C {weather_cache['text']} {weather_cache['humidity']}%")
        return False

# ==================== HTML 页面 ====================
HTML_PAGE = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ESP32 智能面板</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:sans-serif;background:linear-gradient(135deg,#1a1a3e,#0d0d2b);
min-height:100vh;display:flex;justify-content:center;align-items:center;padding:15px}
.c{background:#fff;border-radius:18px;padding:25px;max-width:420px;width:100%}
h1{text-align:center;color:#333;font-size:22px}
.sub{text-align:center;color:#888;font-size:12px;margin-bottom:14px}
.s{background:#f8f9fa;border-radius:12px;padding:16px;margin-bottom:14px}
.st{font-size:15px;font-weight:700;color:#555;margin-bottom:12px}
.led-box{display:flex;align-items:center;justify-content:center;gap:10px;margin-bottom:12px}
.led{width:32px;height:32px;border-radius:50%;background:#ccc;transition:.3s}
.led.on{background:#ffeb3b;box-shadow:0 0 25px #ffeb3b}
.btns{display:flex;gap:10px;justify-content:center}
.btn{padding:12px 32px;border:none;border-radius:8px;font-size:15px;font-weight:700;cursor:pointer;color:#fff}
.btn-on{background:#4caf50}.btn-off{background:#f44336}
.wg{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.wi{text-align:center;padding:12px;background:#fff;border-radius:8px}
.wv{font-size:26px;font-weight:700;color:#333}
.wl{font-size:11px;color:#999;margin-top:3px}
.rf{width:100%;margin-top:10px;padding:10px;background:#2196F3;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer}
.badge{background:#ff9800;color:#fff;padding:2px 8px;border-radius:10px;font-size:10px}
.city-row{display:flex;gap:8px;margin-top:10px}
.city-row input{flex:1;padding:8px 12px;border:1px solid #ddd;border-radius:6px;font-size:13px}
.city-row button{padding:8px 16px;background:#667eea;color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:13px}
.foot{text-align:center;color:#bbb;font-size:11px;margin-top:12px}
</style>
</head>
<body>
<div class="c">
<h1>ESP32 智能面板</h1>
<p class="sub">WiFi + Web + 后端服务 | 物联网实训</p>
<div style="text-align:center">
  <span class="badge" id="srcBadge">仿真运行中</span>
</div>

<div class="s">
<div class="st">LED 远程控制</div>
<div class="led-box">
<span>状态:</span><div class="led" id="ld"></div><span id="ls">检测中</span>
</div>
<div class="btns">
<button class="btn btn-on" onclick="ctl(1)">开灯</button>
<button class="btn btn-off" onclick="ctl(0)">关灯</button>
</div>
</div>

<div class="s">
<div class="st">天气预报</div>
<div class="wg">
<div class="wi"><div class="wv" id="tp">--</div><div class="wl">温度(C)</div></div>
<div class="wi"><div class="wv" id="hm">--</div><div class="wl">湿度(%)</div></div>
<div class="wi"><div class="wv" id="tx">--</div><div class="wl">天气</div></div>
<div class="wi"><div class="wv" id="ct">北京</div><div class="wl">城市</div></div>
</div>
<div class="city-row">
<input type="text" id="cityIn" placeholder="输入城市...">
<button onclick="setCity()">切换</button>
</div>
<button class="rf" onclick="rf()">刷新天气</button>
</div>

<p class="foot">ESP32 WiFi Web Server (仿真)</p>
</div>
<script>
function ctl(o){fetch('/led/'+(o?'on':'off')).then(()=>{document.getElementById('ld').className='led'+(o?' on':'');document.getElementById('ls').textContent=o?'已开':'已关'})}
function rf(){fetch('/weather').then(r=>r.json()).then(j=>{document.getElementById('tp').textContent=j.temp+'C';document.getElementById('hm').textContent=j.humidity+'%';document.getElementById('tx').textContent=j.text;document.getElementById('ct').textContent=j.city})}
function setCity(){var c=document.getElementById('cityIn').value;if(c){fetch('/city?c='+encodeURIComponent(c)).then(r=>r.json()).then(j=>{document.getElementById('ct').textContent=j.city;document.getElementById('tp').textContent=j.temp+'C';document.getElementById('hm').textContent=j.humidity+'%';document.getElementById('tx').textContent=j.text})}}
fetch('/led/status').then(r=>r.text()).then(v=>{document.getElementById('ld').className='led'+(v=='1'?' on':'');document.getElementById('ls').textContent=v=='1'?'已开':'已关'});rf();
</script>
</body>
</html>"""

# ==================== HTTP 请求处理器 ====================
class ESP32Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        global LED_STATE, weather_cache

        if self.path == "/":
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(HTML_PAGE.encode("utf-8"))
            serial_print("[Web] 首页请求")

        elif self.path == "/led/on":
            LED_STATE = True
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"ON")
            serial_print("[GPIO] LED -> ON (GPIO2=HIGH)")

        elif self.path == "/led/off":
            LED_STATE = False
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"OFF")
            serial_print("[GPIO] LED -> OFF (GPIO2=LOW)")

        elif self.path == "/led/status":
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"1" if LED_STATE else b"0")

        elif self.path.startswith("/weather"):
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            self.wfile.write(json.dumps(weather_cache, ensure_ascii=False).encode("utf-8"))

        elif self.path.startswith("/city"):
            # 切换城市
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(self.path).query)
            city = q.get("c", ["北京"])[0]
            weather_cache["city"] = city
            update_weather()
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            self.wfile.write(json.dumps(weather_cache, ensure_ascii=False).encode("utf-8"))
            serial_print(f"[城市] 切换 -> {city}")

        else:
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"404")

    def log_message(self, format, *args):
        pass  # 关闭默认日志，用 serial_print


# ==================== 主程序 ====================
if __name__ == "__main__":
    print("=" * 50)
    print("  ESP32 仿真器启动")
    print("  物联网工程实训-3")
    print("=" * 50)
    print()
    serial_print("[系统] 初始化 GPIO...")
    serial_print("[系统] LED 引脚: GPIO2, 初始状态: OFF")
    serial_print("[WiFi] 正在连接 VelxioNet...")
    time.sleep(0.5)
    serial_print("[WiFi] WiFi 已连接!")
    serial_print(f"[WiFi] IP 地址: 127.0.0.1 (仿真模式)")
    serial_print(f"[Web] Web 服务器启动，端口: {SIM_PORT}")
    serial_print(f"[Web] 浏览器访问: http://localhost:{SIM_PORT}")
    print()

    # 首次获取天气
    serial_print("[天气] 正在获取天气数据...")
    update_weather()

    # 启动 HTTP 服务器
    server = http.server.HTTPServer(("0.0.0.0", SIM_PORT), ESP32Handler)
    print(f"\n{'='*50}")
    print(f"  仿真 ESP32 已就绪")
    print(f"  打开浏览器: http://localhost:{SIM_PORT}")
    print(f"{'='*50}\n")

    # 定时更新天气
    def weather_timer():
        while True:
            time.sleep(30)
            serial_print("[定时] 自动更新天气...")
            update_weather()

    threading.Thread(target=weather_timer, daemon=True).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        serial_print("[系统] 仿真结束")
        server.shutdown()
