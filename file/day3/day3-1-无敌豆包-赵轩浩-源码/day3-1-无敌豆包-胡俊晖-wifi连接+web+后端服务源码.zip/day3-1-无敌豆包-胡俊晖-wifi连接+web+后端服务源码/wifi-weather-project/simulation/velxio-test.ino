// Velxio 快速测试 - 串口输出 + LED 闪烁
// 先确认平台能跑，再换 WiFi 代码

#define LED_PIN 2

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);

  Serial.println("\n================");
  Serial.println("Velxio ESP32 OK!");
  Serial.println("串口通信正常");
  Serial.println("================");
}

void loop() {
  digitalWrite(LED_PIN, HIGH);
  Serial.println("LED ON");
  delay(1000);
  digitalWrite(LED_PIN, LOW);
  Serial.println("LED OFF");
  delay(1000);
}
