package com.weather.controller;

import com.weather.entity.WeatherData;
import com.weather.service.WeatherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 天气 REST API 控制器
 * 提供接口给 ESP32、网页前端调用
 */
@RestController
@RequestMapping("/api/weather")
@CrossOrigin(origins = "*")  // 允许跨域（ESP32/浏览器访问）
public class WeatherController {

    @Autowired
    private WeatherService weatherService;

    /**
     * 获取实时天气
     * GET /api/weather/now?city=北京
     *
     * 返回示例:
     * {
     *   "code": 200,
     *   "data": {
     *     "city": "北京",
     *     "temp": "26",
     *     "text": "晴",
     *     "humidity": "45",
     *     ...
     *   }
     * }
     */
    @GetMapping("/now")
    public Map<String, Object> getNowWeather(@RequestParam(defaultValue = "北京") String city) {
        Map<String, Object> result = new HashMap<>();

        try {
            // 调用和风天气 API 获取实时数据
            WeatherData data = weatherService.getNowWeather(city);

            if (data != null) {
                result.put("code", 200);
                result.put("msg", "success");
                result.put("data", weatherService.toSimpleMap(data));
            } else {
                // 如果 API 调用失败，尝试从数据库获取最近一条
                WeatherData cache = weatherService.getLatestWeather(city);
                if (cache != null) {
                    result.put("code", 200);
                    result.put("msg", "success (from cache)");
                    result.put("data", weatherService.toSimpleMap(cache));
                } else {
                    result.put("code", 500);
                    result.put("msg", "获取天气数据失败");
                    result.put("data", null);
                }
            }
        } catch (Exception e) {
            result.put("code", 500);
            result.put("msg", "服务器内部错误: " + e.getMessage());
            result.put("data", null);
        }

        return result;
    }

    /**
     * 获取天气预报 (简化版 - 兼容 ESP32)
     * GET /api/weather/forecast?city=北京
     */
    @GetMapping("/forecast")
    public Map<String, Object> getForecast(@RequestParam(defaultValue = "北京") String city) {
        Map<String, Object> result = new HashMap<>();

        try {
            WeatherData data = weatherService.getNowWeather(city);
            if (data != null) {
                result.put("code", 200);
                result.put("msg", "success");
                result.put("data", weatherService.toSimpleMap(data));
            } else {
                result.put("code", 500);
                result.put("msg", "获取预报失败");
                result.put("data", null);
            }
        } catch (Exception e) {
            result.put("code", 500);
            result.put("msg", e.getMessage());
            result.put("data", null);
        }

        return result;
    }

    /**
     * 查询城市 Location ID
     * GET /api/weather/city?name=北京
     */
    @GetMapping("/city")
    public Map<String, Object> getCityLocationId(@RequestParam String name) {
        Map<String, Object> result = new HashMap<>();
        String locationId = weatherService.getLocationId(name);

        if (locationId != null) {
            result.put("code", 200);
            result.put("city", name);
            result.put("locationId", locationId);
        } else {
            result.put("code", 404);
            result.put("msg", "未找到该城市");
        }

        return result;
    }

    /**
     * 获取最近 N 条天气历史记录
     * GET /api/weather/history?city=北京&limit=10
     */
    @GetMapping("/history")
    public Map<String, Object> getHistory(@RequestParam(defaultValue = "北京") String city,
                                          @RequestParam(defaultValue = "10") int limit) {
        Map<String, Object> result = new HashMap<>();

        List<WeatherData> list = weatherService.getRecentWeather(city, limit);
        result.put("code", 200);
        result.put("msg", "success");
        result.put("count", list.size());
        result.put("data", list);

        return result;
    }

    /**
     * 健康检查接口
     * GET /api/weather/ping
     */
    @GetMapping("/ping")
    public Map<String, Object> ping() {
        Map<String, Object> result = new HashMap<>();
        result.put("code", 200);
        result.put("msg", "pong");
        result.put("timestamp", System.currentTimeMillis());
        return result;
    }
}
