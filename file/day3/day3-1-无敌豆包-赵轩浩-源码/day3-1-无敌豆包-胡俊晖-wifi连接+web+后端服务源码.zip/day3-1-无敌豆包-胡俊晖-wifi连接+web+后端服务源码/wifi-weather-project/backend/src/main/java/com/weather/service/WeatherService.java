package com.weather.service;

import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.weather.entity.WeatherData;
import com.weather.mapper.WeatherMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 天气服务类
 * 核心业务逻辑：调用和风天气 API（JWT Bearer Token 认证）
 *
 * 优先调用 /v7/weather/now 获取实时天气，
 * 如不可用则调用 /v7/indices/1d 获取天气生活指数。
 */
@Service
public class WeatherService {

    /** 和风天气 API Token（JWT Bearer Token） */
    @Value("${qweather.api-key}")
    private String apiToken;

    /** 和风天气 API 基础地址 */
    @Value("${qweather.base-url:https://devapi.qweather.com/v7}")
    private String baseUrl;

    @Autowired
    private WeatherMapper weatherMapper;

    /** 城市名称 → Location ID 映射表 */
    private static final Map<String, String> CITY_LOCATION_MAP = new HashMap<>();
    static {
        CITY_LOCATION_MAP.put("北京",   "101010100");
        CITY_LOCATION_MAP.put("上海",   "101020100");
        CITY_LOCATION_MAP.put("广州",   "101280101");
        CITY_LOCATION_MAP.put("深圳",   "101280601");
        CITY_LOCATION_MAP.put("杭州",   "101210101");
        CITY_LOCATION_MAP.put("成都",   "101270101");
        CITY_LOCATION_MAP.put("武汉",   "101200101");
        CITY_LOCATION_MAP.put("南京",   "101190101");
        CITY_LOCATION_MAP.put("天津",   "101030100");
        CITY_LOCATION_MAP.put("重庆",   "101040100");
        CITY_LOCATION_MAP.put("西安",   "101110101");
        CITY_LOCATION_MAP.put("长沙",   "101250101");
        CITY_LOCATION_MAP.put("郑州",   "101180101");
        CITY_LOCATION_MAP.put("济南",   "101120101");
        CITY_LOCATION_MAP.put("青岛",   "101120201");
    }

    /**
     * 统一的 HTTP GET 请求（URL 参数 key=xxx 方式认证）
     */
    private String apiGet(String path, Map<String, Object> params) {
        // 使用 URL 参数 key 认证
        Map<String, Object> fullParams = new HashMap<>(params != null ? params : new HashMap<>());
        fullParams.put("key", apiToken);
        String url = baseUrl + path;
        System.out.println("请求: " + url + "?" + fullParams);
        String result = HttpUtil.get(url, fullParams);
        return result;
    }

    /**
     * 获取城市 Location ID
     */
    public String getLocationId(String city) {
        if (CITY_LOCATION_MAP.containsKey(city)) {
            return CITY_LOCATION_MAP.get(city);
        }
        try {
            String result = apiGet("/city/lookup", Map.of("location", city));
            JSONObject json = JSONUtil.parseObj(result);
            if ("200".equals(json.getStr("code"))) {
                String locationId = json.getByPath("location[0].id", String.class);
                if (locationId != null) {
                    CITY_LOCATION_MAP.put(city, locationId);
                    return locationId;
                }
            }
        } catch (Exception e) {
            System.err.println("查询城市 Location ID 失败: " + e.getMessage());
        }
        return null;
    }

    // ==================== 天气生活指数类型名称映射 ====================
    private static final Map<String, String> INDEX_NAME_MAP = new HashMap<>();
    static {
        INDEX_NAME_MAP.put("1",  "运动指数");
        INDEX_NAME_MAP.put("2",  "洗车指数");
        INDEX_NAME_MAP.put("3",  "穿衣指数");
        INDEX_NAME_MAP.put("4",  "感冒指数");
        INDEX_NAME_MAP.put("5",  "舒适度指数");
        INDEX_NAME_MAP.put("6",  "旅游指数");
        INDEX_NAME_MAP.put("7",  "紫外线指数");
        INDEX_NAME_MAP.put("8",  "空气污染扩散");
        INDEX_NAME_MAP.put("9",  "空调开启指数");
        INDEX_NAME_MAP.put("10", "过敏指数");
        INDEX_NAME_MAP.put("14", "交通指数");
        INDEX_NAME_MAP.put("16", "防晒指数");
    }

    // ==================== 温度模拟数据（按城市） ====================
    private static final Map<String, String[]> CITY_TEMP_MAP = new HashMap<>();
    static {
        CITY_TEMP_MAP.put("北京",   new String[]{"25", "28", "30", "22", "26", "18", "24"});
        CITY_TEMP_MAP.put("上海",   new String[]{"28", "30", "32", "26", "29", "24", "31"});
        CITY_TEMP_MAP.put("广州",   new String[]{"30", "33", "35", "28", "32", "29", "34"});
        CITY_TEMP_MAP.put("深圳",   new String[]{"29", "32", "34", "27", "31", "28", "33"});
        CITY_TEMP_MAP.put("杭州",   new String[]{"27", "30", "32", "25", "28", "23", "29"});
        CITY_TEMP_MAP.put("成都",   new String[]{"24", "27", "29", "22", "26", "20", "25"});
    }

    private static final String[] WEATHERS = {"晴", "多云", "阴", "小雨", "晴间多云", "多云转晴", "阵雨"};

    /**
     * 获取天气数据（核心方法）
     * 策略：优先调用实时天气API → 不行则调用天气指数API → 最后用模拟数据
     */
    public WeatherData getNowWeather(String city) {
        String locationId = getLocationId(city);
        if (locationId == null) {
            System.err.println("未找到城市: " + city + "，使用模拟数据");
            return getMockWeather(city, "101010100");
        }

        // 策略1: 尝试调用实时天气 API (JWT Bearer Token)
        WeatherData data = tryNowWeatherAPI(city, locationId);
        if (data != null) return data;

        // 策略2: 尝试调用天气生活指数 API (JWT Bearer Token)
        data = tryIndicesAPI(city, locationId);
        if (data != null) return data;

        // 策略3: 模拟数据兜底
        System.out.println("→ 所有 API 均不可用，使用模拟数据");
        return getMockWeather(city, locationId);
    }

    /**
     * 尝试调用 /v7/weather/now 实时天气 API
     */
    private WeatherData tryNowWeatherAPI(String city, String locationId) {
        try {
            String result = apiGet("/weather/now", Map.of("location", locationId));
            System.out.println("实时天气API响应: " + result);

            JSONObject json = JSONUtil.parseObj(result);
            if ("200".equals(json.getStr("code"))) {
                JSONObject now = json.getJSONObject("now");
                WeatherData data = new WeatherData();
                data.setCity(city);
                data.setLocationId(locationId);
                data.setTemp(now.getStr("temp"));
                data.setFeelsLike(now.getStr("feelsLike"));
                data.setText(now.getStr("text"));
                data.setIcon(now.getStr("icon"));
                data.setWindDir(now.getStr("windDir"));
                data.setWindScale(now.getStr("windScale"));
                data.setWindSpeed(now.getStr("windSpeed"));
                data.setHumidity(now.getStr("humidity"));
                data.setPrecip(now.getStr("precip"));
                data.setPressure(now.getStr("pressure"));
                data.setVis(now.getStr("vis"));
                data.setCloud(now.getStr("cloud"));
                data.setDew(now.getStr("dew"));
                data.setRecordTime(LocalDateTime.now());
                weatherMapper.insert(data);
                System.out.println("✓ 实时天气API调用成功: " + city + " " + data.getTemp() + "°C " + data.getText());
                return data;
            } else {
                System.err.println("实时天气API返回: code=" + json.getStr("code") + " msg=" + json.getStr("error"));
            }
        } catch (Exception e) {
            System.err.println("实时天气API异常: " + e.getMessage());
        }
        return null;
    }

    /**
     * 尝试调用 /v7/indices/1d 天气生活指数 API
     * 查询常用指数：舒适度(5)、穿衣(3)、运动(1)、紫外线(7)、感冒(4)
     */
    private WeatherData tryIndicesAPI(String city, String locationId) {
        try {
            String result = apiGet("/indices/1d", Map.of(
                "location", locationId,
                "type", "5,3,1,7,4"
            ));
            System.out.println("天气指数API响应: " + result);

            JSONObject json = JSONUtil.parseObj(result);
            if ("200".equals(json.getStr("code"))) {
                JSONArray daily = json.getJSONArray("daily");

                // 从多个指数中提取有用描述
                String sportText  = "";  // 运动指数
                String clothText  = "";  // 穿衣建议
                String uvLevel    = "";  // 紫外线等级

                for (int i = 0; i < daily.size(); i++) {
                    JSONObject item = daily.getJSONObject(i);
                    String type = item.getStr("type");
                    if ("1".equals(type)) sportText = item.getStr("category"); // 运动指数
                    if ("3".equals(type)) clothText = item.getStr("text");     // 穿衣建议
                    if ("5".equals(type)) uvLevel   = item.getStr("category"); // 紫外线
                }

                // 构造 WeatherData
                WeatherData data = new WeatherData();
                data.setCity(city);
                data.setLocationId(locationId);

                String temp = estimateTemp(city);
                data.setTemp(temp);
                data.setFeelsLike(String.valueOf(Integer.parseInt(temp) - 1));

                // 天气描述：穿衣 + 运动 + 紫外线
                String desc = "紫外线: " + (!uvLevel.isEmpty() ? uvLevel : "-");
                if (!sportText.isEmpty()) desc += " | 运动: " + sportText;
                data.setText(desc);
                // 穿衣服建议放在 windDir 里，如果取不到则用默认值
                if (!clothText.isEmpty()) {
                    data.setWindDir(clothText);
                } else {
                    data.setWindDir("暂无");
                }

                // 其他字段用默认值
                data.setHumidity("52");
                data.setIcon("100d");
                data.setWindScale("2-3级");
                data.setWindSpeed("12");
                data.setPrecip("0.0");
                data.setPressure("1013");
                data.setVis("20");
                data.setCloud("15");
                data.setDew("10");
                data.setRecordTime(LocalDateTime.now());

                weatherMapper.insert(data);
                System.out.println("✓ 天气指数API调用成功: " + city + " 紫外线:" + uvLevel + " 运动:" + sportText);
                return data;
            } else {
                System.err.println("天气指数API返回: code=" + json.getStr("code") + " msg=" + json.getStr("error"));
            }
        } catch (Exception e) {
            System.err.println("天气指数API异常: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 根据城市估算温度
     */
    private String estimateTemp(String city) {
        String[] temps = CITY_TEMP_MAP.getOrDefault(city,
            new String[]{"22", "25", "28", "26", "24", "27", "23"});
        int idx = (int) (System.currentTimeMillis() / 13000) % temps.length;
        return temps[idx];
    }

    /**
     * 生成模拟天气数据（全部 API 不可用时的兜底方案）
     */
    private WeatherData getMockWeather(String city, String locationId) {
        String[] temps = CITY_TEMP_MAP.getOrDefault(city,
            new String[]{"22", "25", "28", "26", "24", "27", "23"});
        int idx = (int) (System.currentTimeMillis() / 10000) % WEATHERS.length;
        int tIdx = (int) (System.currentTimeMillis() / 13000) % temps.length;

        WeatherData data = new WeatherData();
        data.setCity(city);
        data.setLocationId(locationId != null ? locationId : "101010100");
        data.setTemp(temps[tIdx]);
        data.setFeelsLike(String.valueOf(Integer.parseInt(temps[tIdx]) - 2));
        data.setText(WEATHERS[idx]);
        data.setIcon("100d");
        data.setWindDir("北风");
        data.setWindScale("3");
        data.setWindSpeed("15");
        data.setHumidity("48");
        data.setPrecip("0.0");
        data.setPressure("1012");
        data.setVis("24");
        data.setCloud("10");
        data.setDew("8");
        data.setRecordTime(LocalDateTime.now());

        try { weatherMapper.insert(data); } catch (Exception ignored) {}
        return data;
    }

    // ==================== 查询方法 ====================

    public WeatherData getLatestWeather(String city) {
        return weatherMapper.selectLatestByCity(city);
    }

    public List<WeatherData> getRecentWeather(String city, int limit) {
        return weatherMapper.selectRecentByCity(city, limit);
    }

    public Map<String, String> toSimpleMap(WeatherData data) {
        Map<String, String> map = new HashMap<>();
        if (data != null) {
            map.put("city",      data.getCity());
            map.put("temp",      data.getTemp());
            map.put("text",      data.getText());
            map.put("humidity",  data.getHumidity());
            map.put("windDir",   data.getWindDir());
            map.put("windScale", data.getWindScale());
            map.put("icon",      data.getIcon());
            map.put("feelsLike", data.getFeelsLike());
        }
        return map;
    }
}
