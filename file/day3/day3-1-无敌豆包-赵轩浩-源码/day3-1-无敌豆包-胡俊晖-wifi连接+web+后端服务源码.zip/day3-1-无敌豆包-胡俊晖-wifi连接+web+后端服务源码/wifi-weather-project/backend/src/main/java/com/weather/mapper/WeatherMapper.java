package com.weather.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.weather.entity.WeatherData;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 天气数据 Mapper 接口
 * 继承 MyBatis-Plus BaseMapper，自带 CRUD 方法
 */
public interface WeatherMapper extends BaseMapper<WeatherData> {

    /**
     * 查询某个城市最新的天气记录
     */
    @Select("SELECT * FROM t_weather_record WHERE city = #{city} " +
            "ORDER BY record_time DESC LIMIT 1")
    WeatherData selectLatestByCity(@Param("city") String city);

    /**
     * 查询某个城市最近 N 条天气记录
     */
    @Select("SELECT * FROM t_weather_record WHERE city = #{city} " +
            "ORDER BY record_time DESC LIMIT #{limit}")
    List<WeatherData> selectRecentByCity(@Param("city") String city,
                                         @Param("limit") int limit);

    /**
     * 查询最近 24 小时内所有城市的天气记录
     */
    @Select("SELECT * FROM t_weather_record " +
            "WHERE record_time > DATE_SUB(NOW(), INTERVAL 24 HOUR) " +
            "ORDER BY record_time DESC")
    List<WeatherData> selectAllRecent();
}
