package com.weather.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.time.LocalDateTime;

/**
 * 天气数据实体类
 * 对应数据库表 t_weather_record
 */
@TableName("t_weather_record")
public class WeatherData {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 城市名称 */
    private String city;

    /** 城市 Location ID (和风天气) */
    private String locationId;

    /** 当前温度 (°C) */
    private String temp;

    /** 体感温度 (°C) */
    private String feelsLike;

    /** 天气状况文字描述 */
    private String text;

    /** 天气图标代码 */
    private String icon;

    /** 风向 */
    private String windDir;

    /** 风力等级 */
    private String windScale;

    /** 风速 (km/h) */
    private String windSpeed;

    /** 相对湿度 (%) */
    private String humidity;

    /** 降水量 (mm) */
    private String precip;

    /** 大气压强 (hPa) */
    private String pressure;

    /** 能见度 (km) */
    private String vis;

    /** 云量 (%) */
    private String cloud;

    /** 露点温度 */
    private String dew;

    /** 数据记录时间 */
    private LocalDateTime recordTime;

    // ==================== Getter & Setter ====================
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public String getLocationId() { return locationId; }
    public void setLocationId(String locationId) { this.locationId = locationId; }

    public String getTemp() { return temp; }
    public void setTemp(String temp) { this.temp = temp; }

    public String getFeelsLike() { return feelsLike; }
    public void setFeelsLike(String feelsLike) { this.feelsLike = feelsLike; }

    public String getText() { return text; }
    public void setText(String text) { this.text = text; }

    public String getIcon() { return icon; }
    public void setIcon(String icon) { this.icon = icon; }

    public String getWindDir() { return windDir; }
    public void setWindDir(String windDir) { this.windDir = windDir; }

    public String getWindScale() { return windScale; }
    public void setWindScale(String windScale) { this.windScale = windScale; }

    public String getWindSpeed() { return windSpeed; }
    public void setWindSpeed(String windSpeed) { this.windSpeed = windSpeed; }

    public String getHumidity() { return humidity; }
    public void setHumidity(String humidity) { this.humidity = humidity; }

    public String getPrecip() { return precip; }
    public void setPrecip(String precip) { this.precip = precip; }

    public String getPressure() { return pressure; }
    public void setPressure(String pressure) { this.pressure = pressure; }

    public String getVis() { return vis; }
    public void setVis(String vis) { this.vis = vis; }

    public String getCloud() { return cloud; }
    public void setCloud(String cloud) { this.cloud = cloud; }

    public String getDew() { return dew; }
    public void setDew(String dew) { this.dew = dew; }

    public LocalDateTime getRecordTime() { return recordTime; }
    public void setRecordTime(LocalDateTime recordTime) { this.recordTime = recordTime; }

    @Override
    public String toString() {
        return "WeatherData{" +
                "city='" + city + '\'' +
                ", temp='" + temp + "'°C" +
                ", text='" + text + '\'' +
                ", humidity='" + humidity + "%'" +
                ", recordTime=" + recordTime +
                '}';
    }
}
