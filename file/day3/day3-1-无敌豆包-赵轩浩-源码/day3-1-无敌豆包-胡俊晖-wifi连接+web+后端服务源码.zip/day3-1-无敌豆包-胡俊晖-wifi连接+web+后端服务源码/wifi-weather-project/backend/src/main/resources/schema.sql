-- 天气记录表（H2 自动建表，同时兼容 MySQL）
CREATE TABLE IF NOT EXISTS t_weather_record (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    city        VARCHAR(50)  DEFAULT NULL,
    location_id VARCHAR(20)  DEFAULT NULL,
    temp        VARCHAR(10)  DEFAULT NULL,
    feels_like  VARCHAR(10)  DEFAULT NULL,
    text        VARCHAR(50)  DEFAULT NULL,
    icon        VARCHAR(10)  DEFAULT NULL,
    wind_dir    VARCHAR(500)  DEFAULT NULL,
    wind_scale  VARCHAR(10)  DEFAULT NULL,
    wind_speed  VARCHAR(10)  DEFAULT NULL,
    humidity    VARCHAR(10)  DEFAULT NULL,
    precip      VARCHAR(10)  DEFAULT NULL,
    pressure    VARCHAR(10)  DEFAULT NULL,
    vis         VARCHAR(10)  DEFAULT NULL,
    cloud       VARCHAR(10)  DEFAULT NULL,
    dew         VARCHAR(10)  DEFAULT NULL,
    record_time TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_city ON t_weather_record(city);
CREATE INDEX IF NOT EXISTS idx_record_time ON t_weather_record(record_time);
