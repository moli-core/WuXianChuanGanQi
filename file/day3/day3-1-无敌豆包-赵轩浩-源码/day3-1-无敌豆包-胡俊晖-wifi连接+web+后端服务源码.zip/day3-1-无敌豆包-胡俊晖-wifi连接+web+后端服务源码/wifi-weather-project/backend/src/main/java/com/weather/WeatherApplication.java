package com.weather;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 天气预报后端服务 - 启动类
 * 物联网工程实训-3: WiFi + Web服务 + 后端服务
 */
@SpringBootApplication
@MapperScan("com.weather.mapper")
public class WeatherApplication {

    public static void main(String[] args) {
        SpringApplication.run(WeatherApplication.class, args);
        System.out.println("========================================");
        System.out.println("天气预报后端服务启动成功！");
        System.out.println("访问地址: http://localhost:8080");
        System.out.println("天气API: http://localhost:8080/api/weather/now?city=北京");
        System.out.println("========================================");
    }
}
