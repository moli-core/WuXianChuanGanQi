-- ============================================================
-- 天气预报后端服务 - 数据库初始化脚本
-- 物联网工程实训-3: WiFi + Web服务 + 后端服务
-- ============================================================

-- 1. 创建数据库
CREATE DATABASE IF NOT EXISTS weather_db
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_unicode_ci;

USE weather_db;

-- 2. 创建天气记录表
CREATE TABLE IF NOT EXISTS t_weather_record (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '主键ID',
    city        VARCHAR(50)  NOT NULL COMMENT '城市名称',
    location_id VARCHAR(20)  DEFAULT NULL COMMENT '和风天气 Location ID',
    temp        VARCHAR(10)  DEFAULT NULL COMMENT '当前温度 (°C)',
    feels_like  VARCHAR(10)  DEFAULT NULL COMMENT '体感温度 (°C)',
    text        VARCHAR(50)  DEFAULT NULL COMMENT '天气状况文字描述',
    icon        VARCHAR(10)  DEFAULT NULL COMMENT '天气图标代码',
    wind_dir    VARCHAR(500)  DEFAULT NULL COMMENT '风向 / 穿衣建议',
    wind_scale  VARCHAR(10)  DEFAULT NULL COMMENT '风力等级',
    wind_speed  VARCHAR(10)  DEFAULT NULL COMMENT '风速 (km/h)',
    humidity    VARCHAR(10)  DEFAULT NULL COMMENT '相对湿度 (%)',
    precip      VARCHAR(10)  DEFAULT NULL COMMENT '降水量 (mm)',
    pressure    VARCHAR(10)  DEFAULT NULL COMMENT '大气压强 (hPa)',
    vis         VARCHAR(10)  DEFAULT NULL COMMENT '能见度 (km)',
    cloud       VARCHAR(10)  DEFAULT NULL COMMENT '云量 (%)',
    dew         VARCHAR(10)  DEFAULT NULL COMMENT '露点温度',
    record_time DATETIME     DEFAULT CURRENT_TIMESTAMP COMMENT '数据记录时间',

    INDEX idx_city (city),
    INDEX idx_record_time (record_time),
    INDEX idx_city_time (city, record_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='天气记录表';

-- 3. 插入测试数据（可选）
INSERT INTO t_weather_record (city, location_id, temp, feels_like, text, icon,
                               wind_dir, wind_scale, wind_speed, humidity,
                               precip, pressure, vis, cloud, dew, record_time)
VALUES
('北京', '101010100', '26', '24', '晴', '100d',
 '北风', '3', '15', '35', '0.0', '1012', '24', '10', '8', NOW());
