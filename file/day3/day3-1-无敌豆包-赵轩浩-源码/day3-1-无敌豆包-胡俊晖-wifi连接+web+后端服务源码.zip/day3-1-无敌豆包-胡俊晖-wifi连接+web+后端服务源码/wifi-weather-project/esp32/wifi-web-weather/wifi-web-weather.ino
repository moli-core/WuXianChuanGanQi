/*
 * WiFi + Web服务 + 天气预报 + 后端服务
 * 物联网工程实训-3 综合项目
 *
 * 功能：
 *   1. ESP32 连接 WiFi (STA模式)
 *   2. 内置 Web 服务器，提供控制面板网页
 *   3. 远程控制 LED 亮灭
 *   4. 从后端服务获取天气预报数据
 *   5. OLED 屏幕显示天气信息
 *
 * 硬件连接：
 *   LED -> GPIO 2 (ESP32 内置LED)
 *   OLED SDA -> GPIO 21
 *   OLED SCL -> GPIO 22
 *   OLED VCC -> 3.3V
 *   OLED GND -> GND
 */

#include <WiFi.h>
#include <WebServer.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <Adafruit_SSD1306.h>
#include <Wire.h>

// ==================== WiFi 配置 ====================
// 连接热点名称（文档中为 ryX50）
const char* ssid = "ryX50";
const char* password = "12345678";  // 请修改为实际的热点密码

// ==================== 后端服务配置 ====================
// SpringBoot 后端服务的地址（电脑IP + 端口）
const char* backendHost = "http://192.168.137.1:8080";
const char* weatherApi  = "/api/weather/now";    // 获取实时天气
const char* forecastApi = "/api/weather/forecast"; // 获取天气预报
const char* cityApi     = "/api/weather/city";     // 城市查询

// ==================== OLED 屏幕配置 ====================
#define SCREEN_WIDTH  128
#define SCREEN_HEIGHT 64
#define OLED_ADDR     0x3C
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// ==================== LED 引脚 ====================
#define LED_PIN 2  // ESP32 板载 LED

// ==================== Web 服务器 ====================
WebServer server(80);

// ==================== 全局变量 ====================
String currentTemp     = "--";
String currentWeather  = "加载中...";
String currentHumidity = "--";
String currentCity     = "北京";
unsigned long lastWeatherUpdate = 0;
const unsigned long weatherUpdateInterval = 60000; // 每60秒更新一次天气

// ==================== 函数声明 ====================
void connectWiFi();
void setupWebServer();
void handleRoot();
void handleLEDOn();
void handleLEDOff();
void handleLEDStatus();
void handleWeather();
void handleSetCity();
void updateWeather();
void displayWeatherOLED();
String httpGetRequest(const char* url);

// ==================== 初始化 ====================
void setup() {
  Serial.begin(115200);
  delay(1000);

  // 初始化 LED
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  // 初始化 OLED
  Wire.begin(21, 22);
  if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    Serial.println("OLED 初始化失败！");
  } else {
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(0, 0);
    display.println("系统启动中...");
    display.display();
  }

  // 连接 WiFi
  connectWiFi();

  // 启动 Web 服务器
  setupWebServer();

  Serial.println("========================================");
  Serial.println("系统启动完成！");
  Serial.print("请在浏览器访问: http://");
  Serial.println(WiFi.localIP());
  Serial.println("========================================");

  // 首次获取天气
  updateWeather();
}

// ==================== 主循环 ====================
void loop() {
  server.handleClient();

  // 定时更新天气
  if (millis() - lastWeatherUpdate > weatherUpdateInterval) {
    updateWeather();
  }
}

// ==================== WiFi 连接 ====================
void connectWiFi() {
  Serial.print("正在连接 WiFi: ");
  Serial.println(ssid);

  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("连接WiFi中...");
  display.print("SSID: ");
  display.println(ssid);
  display.display();

  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);

  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 30) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi 连接成功！");
    Serial.print("IP 地址: ");
    Serial.println(WiFi.localIP());

    display.clearDisplay();
    display.setCursor(0, 0);
    display.println("WiFi 已连接");
    display.print("IP: ");
    display.println(WiFi.localIP());
    display.display();
    delay(1000);
  } else {
    Serial.println("\nWiFi 连接失败！请检查热点名称和密码。");
    display.clearDisplay();
    display.setCursor(0, 0);
    display.println("WiFi 连接失败!");
    display.display();
  }
}

// ==================== Web 服务器设置 ====================
void setupWebServer() {
  // 首页 - 控制面板
  server.on("/", handleRoot);

  // LED 控制接口
  server.on("/led/on", handleLEDOn);
  server.on("/led/off", handleLEDOff);
  server.on("/led/status", handleLEDStatus);

  // 天气接口
  server.on("/weather", handleWeather);
  server.on("/setCity", handleSetCity);

  // 启动服务器
  server.begin();
  Serial.println("Web 服务器已启动");
}

// ==================== 首页处理 ====================
void handleRoot() {
  String html = R"rawliteral(
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ESP32 智能控制面板</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: 'Microsoft YaHei', sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
    }
    .container {
      background: white;
      border-radius: 20px;
      padding: 30px;
      max-width: 450px;
      width: 100%;
      box-shadow: 0 20px 60px rgba(0,0,0,0.3);
    }
    h1 {
      text-align: center;
      color: #333;
      margin-bottom: 8px;
      font-size: 24px;
    }
    .subtitle { text-align: center; color: #888; margin-bottom: 25px; font-size: 13px; }

    .card {
      background: #f8f9fa;
      border-radius: 15px;
      padding: 20px;
      margin-bottom: 20px;
    }
    .card-title {
      font-size: 16px;
      font-weight: bold;
      color: #555;
      margin-bottom: 15px;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    /* LED 控制区域 */
    .led-status {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 20px;
      margin-bottom: 15px;
    }
    .led-indicator {
      width: 30px; height: 30px;
      border-radius: 50%;
      background: #ccc;
      transition: all 0.3s;
      box-shadow: 0 0 10px rgba(0,0,0,0.2);
    }
    .led-indicator.on {
      background: #ffeb3b;
      box-shadow: 0 0 25px #ffeb3b;
    }
    .btn-group {
      display: flex;
      gap: 15px;
      justify-content: center;
    }
    .btn {
      padding: 12px 35px;
      border: none;
      border-radius: 10px;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
      transition: all 0.3s;
      color: white;
    }
    .btn-on  { background: #4caf50; }
    .btn-on:hover  { background: #45a049; transform: scale(1.05); }
    .btn-off { background: #f44336; }
    .btn-off:hover { background: #da190b; transform: scale(1.05); }

    /* 天气信息区域 */
    .weather-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
    }
    .weather-item {
      text-align: center;
      padding: 12px;
      background: white;
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    }
    .weather-value {
      font-size: 28px;
      font-weight: bold;
      color: #333;
    }
    .weather-label {
      font-size: 12px;
      color: #999;
      margin-top: 4px;
    }
    .city-select {
      display: flex;
      gap: 10px;
      margin-top: 10px;
    }
    .city-select input {
      flex: 1;
      padding: 10px;
      border: 2px solid #e0e0e0;
      border-radius: 8px;
      font-size: 14px;
    }
    .city-select button {
      padding: 10px 20px;
      background: #667eea;
      color: white;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-size: 14px;
    }
    .refresh-btn {
      width: 100%;
      margin-top: 10px;
      padding: 10px;
      background: #2196F3;
      color: white;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-size: 14px;
    }
    .refresh-btn:hover { background: #1976D2; }

    .footer {
      text-align: center;
      color: #bbb;
      font-size: 11px;
      margin-top: 20px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>🌐 ESP32 智能面板</h1>
    <p class="subtitle">物联网工程实训 · WiFi + Web + 后端服务</p>

    <!-- LED 控制卡片 -->
    <div class="card">
      <div class="card-title">💡 LED 远程控制</div>
      <div class="led-status">
        <span>状态：</span>
        <div class="led-indicator" id="ledIndicator"></div>
        <span id="ledStatusText">检测中...</span>
      </div>
      <div class="btn-group">
        <button class="btn btn-on" onclick="controlLED('on')">🔆 开灯</button>
        <button class="btn btn-off" onclick="controlLED('off')">🌑 关灯</button>
      </div>
    </div>

    <!-- 天气信息卡片 -->
    <div class="card">
      <div class="card-title">🌤 天气预报</div>
      <div class="weather-grid">
        <div class="weather-item">
          <div class="weather-value" id="temp">--°</div>
          <div class="weather-label">当前温度</div>
        </div>
        <div class="weather-item">
          <div class="weather-value" id="humidity">--%</div>
          <div class="weather-label">空气湿度</div>
        </div>
        <div class="weather-item">
          <div class="weather-value" id="weatherText">--</div>
          <div class="weather-label">天气状况</div>
        </div>
        <div class="weather-item">
          <div class="weather-value" id="cityName">--</div>
          <div class="weather-label">当前城市</div>
        </div>
      </div>
      <div class="city-select">
        <input type="text" id="cityInput" placeholder="输入城市名...">
        <button onclick="setCity()">切换</button>
      </div>
      <button class="refresh-btn" onclick="refreshWeather()">🔄 刷新天气</button>
    </div>

    <p class="footer">ESP32 WiFi Web Server · 物联网工程实训</p>
  </div>

  <script>
    // 页面加载时获取状态
    window.onload = function() {
      checkLEDStatus();
      refreshWeather();
    };

    // 获取 LED 状态
    function checkLEDStatus() {
      fetch('/led/status')
        .then(res => res.text())
        .then(data => {
          updateLEDUI(data === '1');
        });
    }

    // 控制 LED
    function controlLED(action) {
      fetch('/led/' + action)
        .then(res => res.text())
        .then(data => {
          updateLEDUI(action === 'on');
        });
    }

    // 更新 LED UI
    function updateLEDUI(isOn) {
      const indicator = document.getElementById('ledIndicator');
      const statusText = document.getElementById('ledStatusText');
      if (isOn) {
        indicator.className = 'led-indicator on';
        statusText.textContent = '已开启';
      } else {
        indicator.className = 'led-indicator';
        statusText.textContent = '已关闭';
      }
    }

    // 刷新天气
    function refreshWeather() {
      fetch('/weather')
        .then(res => res.json())
        .then(data => {
          if (data.temp) {
            document.getElementById('temp').textContent = data.temp + '°C';
            document.getElementById('humidity').textContent = data.humidity + '%';
            document.getElementById('weatherText').textContent = data.text;
            document.getElementById('cityName').textContent = data.city;
          }
        })
        .catch(err => {
          document.getElementById('weatherText').textContent = '获取失败';
        });
    }

    // 设置城市
    function setCity() {
      var city = document.getElementById('cityInput').value;
      if (city) {
        fetch('/setCity?city=' + encodeURIComponent(city))
          .then(res => res.text())
          .then(data => {
            document.getElementById('cityName').textContent = city;
            refreshWeather();
          });
      }
    }
  </script>
</body>
</html>
  )rawliteral";

  server.send(200, "text/html; charset=utf-8", html);
}

// ==================== LED 控制处理 ====================
void handleLEDOn() {
  digitalWrite(LED_PIN, HIGH);
  Serial.println("LED 已开启");
  server.send(200, "text/plain", "LED ON");
}

void handleLEDOff() {
  digitalWrite(LED_PIN, LOW);
  Serial.println("LED 已关闭");
  server.send(200, "text/plain", "LED OFF");
}

void handleLEDStatus() {
  int status = digitalRead(LED_PIN);
  server.send(200, "text/plain", String(status));
}

// ==================== 天气数据处理 ====================
void handleWeather() {
  String json = "{";
  json += "\"temp\":\"" + currentTemp + "\",";
  json += "\"humidity\":\"" + currentHumidity + "\",";
  json += "\"text\":\"" + currentWeather + "\",";
  json += "\"city\":\"" + currentCity + "\"";
  json += "}";
  server.send(200, "application/json", json);
}

void handleSetCity() {
  if (server.hasArg("city")) {
    currentCity = server.arg("city");
    Serial.print("城市切换为: ");
    Serial.println(currentCity);
    updateWeather();
    server.send(200, "text/plain", "城市已切换为: " + currentCity);
  } else {
    server.send(400, "text/plain", "缺少 city 参数");
  }
}

// ==================== 天气更新 ====================
void updateWeather() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi 未连接，跳过天气更新");
    return;
  }

  Serial.println("正在获取天气数据...");

  HTTPClient http;
  http.setTimeout(5000);

  // 调用后端服务 API 获取天气
  String url = String(backendHost) + weatherApi + "?city=" + currentCity;
  Serial.println("请求 URL: " + url);

  http.begin(url);
  int httpCode = http.GET();

  if (httpCode == 200) {
    String payload = http.getString();
    Serial.println("收到天气数据: " + payload);

    // 解析 JSON 数据
    DynamicJsonDocument doc(1024);
    DeserializationError error = deserializeJson(doc, payload);

    if (!error) {
      // 解析温度
      if (doc.containsKey("temp")) {
        currentTemp = doc["temp"].as<String>();
      }
      // 解析天气描述
      if (doc.containsKey("text")) {
        currentWeather = doc["text"].as<String>();
      }
      // 解析湿度
      if (doc.containsKey("humidity")) {
        currentHumidity = doc["humidity"].as<String>();
      }
      // 解析城市
      if (doc.containsKey("city")) {
        currentCity = doc["city"].as<String>();
      }

      Serial.println("天气更新成功！");
      Serial.printf("城市: %s | 温度: %s°C | 天气: %s | 湿度: %s%%\n",
                    currentCity.c_str(), currentTemp.c_str(),
                    currentWeather.c_str(), currentHumidity.c_str());

      // 更新 OLED 显示
      displayWeatherOLED();
    } else {
      Serial.println("JSON 解析失败");
    }
  } else {
    Serial.printf("HTTP 请求失败，错误码: %d\n", httpCode);
    // 如果后端不可用，尝试直接调用和风天气 API
    directWeatherAPI();
  }

  http.end();
  lastWeatherUpdate = millis();
}

// ==================== 直接调用和风天气 API (备用方案) ====================
void directWeatherAPI() {
  // 和风天气 API 配置
  const char* qweatherKey = "YOUR_QWEATHER_API_KEY";  // 请替换为你的和风天气 API Key
  const char* qweatherHost = "https://devapi.qweather.com/v7/weather/now";

  // 首先需要根据城市名获取 Location ID
  // 这里简化处理，直接使用北京的 Location ID: 101010100
  String locationID = "101010100";  // 北京的 Location ID

  HTTPClient http;
  http.setTimeout(5000);

  String url = String(qweatherHost) + "?location=" + locationID + "&key=" + qweatherKey;
  http.begin(url);

  int httpCode = http.GET();
  if (httpCode == 200) {
    String payload = http.getString();
    DynamicJsonDocument doc(2048);
    DeserializationError error = deserializeJson(doc, payload);

    if (!error && doc["code"].as<String>() == "200") {
      JsonObject now = doc["now"];
      currentTemp = now["temp"].as<String>();
      currentWeather = now["text"].as<String>();
      currentHumidity = now["humidity"].as<String>();

      Serial.println("直接从和风天气获取成功！");
      displayWeatherOLED();
    }
  }
  http.end();
}

// ==================== OLED 显示天气 ====================
void displayWeatherOLED() {
  display.clearDisplay();

  // 第一行：标题
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("=== 天气预报 ===");

  // 第三行：城市
  display.setCursor(0, 18);
  display.print("城市: ");
  display.println(currentCity);

  // 第四行：温度
  display.setCursor(0, 30);
  display.print("温度: ");
  display.print(currentTemp);
  display.println(" C");

  // 第五行：天气
  display.setCursor(0, 42);
  display.print("天气: ");
  display.println(currentWeather);

  // 第六行：湿度
  display.setCursor(0, 54);
  display.print("湿度: ");
  display.print(currentHumidity);
  display.println(" %");

  display.display();
}

// ==================== HTTP GET 工具函数 ====================
String httpGetRequest(const char* url) {
  HTTPClient http;
  http.setTimeout(5000);
  http.begin(url);
  int httpCode = http.GET();
  String payload = "";
  if (httpCode == 200) {
    payload = http.getString();
  }
  http.end();
  return payload;
}
