# WiFi + Web服务 + 天气预报 + 后端服务

## 📋 项目简介

物联网工程实训-3 综合项目。实现 **ESP32 WiFi连接 → 内置Web服务器 → 远程控制LED → 获取天气预报 → SpringBoot后端 → 和风天气API** 完整链路。

## 🏗 项目架构

```
┌─────────────────┐     HTTP/JSON      ┌──────────────────┐     HTTP/JSON      ┌──────────────┐
│   ESP32 设备     │ ◄────────────────► │  SpringBoot 后端  │ ◄────────────────► │  和风天气 API │
│                 │                    │                  │                    │              │
│  • WiFi 连接     │    /api/weather/*  │  • REST API      │   /v7/weather/now │  天气预报数据  │
│  • Web 服务器    │                    │  • MyBatis-Plus   │                    │              │
│  • LED 控制      │    /led/on         │  • MySQL 存储     │                    │              │
│  • OLED 显示     │    /led/off        │                  │                    │              │
└─────────────────┘                    └──────────────────┘                    └──────────────┘
       ▲                                      ▲
       │                                      │
       ▼                                      ▼
   浏览器访问                             浏览器/Postman
  http://ESP_IP                         http://localhost:8080
```

## 📁 目录结构

```
wifi-weather-project/
├── esp32/
│   └── wifi-web-weather/
│       └── wifi-web-weather.ino      # ESP32 Arduino 代码
├── backend/
│   ├── pom.xml                       # Maven 依赖
│   ├── sql/
│   │   └── init.sql                  # 数据库建表脚本
│   └── src/main/
│       ├── java/com/weather/
│       │   ├── WeatherApplication.java      # SpringBoot 启动类
│       │   ├── config/
│       │   │   └── RestTemplateConfig.java   # HTTP 客户端配置
│       │   ├── entity/
│       │   │   └── WeatherData.java          # 天气数据实体
│       │   ├── mapper/
│       │   │   └── WeatherMapper.java        # MyBatis Mapper
│       │   ├── service/
│       │   │   └── WeatherService.java       # 天气业务逻辑
│       │   └── controller/
│       │       └── WeatherController.java    # REST API 接口
│       └── resources/
│           └── application.yml       # 配置文件
└── README.md
```

## 🚀 快速开始

### 一、环境准备

| 组件 | 版本/说明 |
|------|----------|
| JDK | 1.8+ |
| Maven | 3.6+ |
| MySQL | 5.7+ 或 8.0+ |
| Arduino IDE | 2.0+ (含 ESP32 开发板支持) |
| 和风天气账号 | https://id.qweather.com (免费注册) |

### 二、后端服务部署

#### 1. 注册和风天气 API

1. 打开 https://id.qweather.com/#/login 注册账号
2. 进入开发控制台 https://console.qweather.com/home?lang=zh
3. 创建项目 → 获取 **API Key**（免费订阅每天 1000 次调用）

#### 2. 初始化数据库

```bash
# 执行 SQL 脚本
mysql -u root -p < backend/sql/init.sql
```

或使用 Navicat / DBeaver 等工具导入 `init.sql`。

#### 3. 修改配置

编辑 `backend/src/main/resources/application.yml`：

```yaml
# 修改数据库连接
spring:
  datasource:
    username: root        # 你的 MySQL 用户名
    password: 123456      # 你的 MySQL 密码

# 修改和风天气 API Key
qweather:
  api-key: YOUR_QWEATHER_API_KEY_HERE   # 替换为你的 API Key
```

#### 4. 启动后端

```bash
cd backend

# 编译打包
mvn clean package -DskipTests

# 启动
java -jar target/weather-backend-1.0.0.jar

# 或者用 Maven 直接启动
mvn spring-boot:run
```

#### 5. 验证后端 API

浏览器访问：
- 健康检查: http://localhost:8080/api/weather/ping
- 实时天气: http://localhost:8080/api/weather/now?city=北京
- 城市查询: http://localhost:8080/api/weather/city?name=上海

### 三、ESP32 部署

#### 1. Arduino IDE 准备工作

1. 安装 **ESP32 开发板支持**（开发板管理器 → 搜索 ESP32 → 安装）
2. 安装所需库（库管理器搜索安装）：
   - `ArduinoJson` by Benoit Blanchon
   - `Adafruit SSD1306` by Adafruit
   - `Adafruit GFX Library` by Adafruit

#### 2. 修改 WiFi 配置

编辑 `esp32/wifi-web-weather/wifi-web-weather.ino`：

```cpp
// 修改为你的 WiFi 热点名称和密码（文档中为 ryX50）
const char* ssid = "ryX50";
const char* password = "12345678";

// 修改后端服务地址（你的电脑 IP + 8080 端口）
const char* backendHost = "http://192.168.137.1:8080";
```

> ⚠️ **重要**：ESP32 和电脑必须在**同一局域网**！后端服务地址填电脑的局域网 IP。

#### 3. 硬件连接

| OLED 引脚 | ESP32 引脚 |
|-----------|------------|
| VCC       | 3.3V       |
| GND       | GND        |
| SDA       | GPIO 21    |
| SCL       | GPIO 22    |

LED 使用 ESP32 板载 LED (GPIO 2)。

#### 4. 上传代码

1. USB 连接 ESP32
2. 选择正确的开发板和端口
3. 点击「上传」按钮

#### 5. 打开控制面板

上传成功后，打开串口监视器查看 IP 地址，在浏览器输入该 IP 即可打开控制面板网页。

### 四、测试 LED 控制

在浏览器访问 `http://<ESP32_IP>`，点击"开灯"/"关灯"按钮测试远程控制。

或用命令行测试：

```bash
# 开灯
curl http://<ESP32_IP>/led/on

# 关灯
curl http://<ESP32_IP>/led/off

# 查看状态
curl http://<ESP32_IP>/led/status
```

## 📡 API 接口说明

### 后端服务 API (SpringBoot :8080)

| 方法 | 路径 | 参数 | 说明 |
|------|------|------|------|
| GET | `/api/weather/now` | `city` (可选, 默认北京) | 获取实时天气 |
| GET | `/api/weather/forecast` | `city` (可选) | 获取天气预报 |
| GET | `/api/weather/city` | `name` (必填) | 查询城市 Location ID |
| GET | `/api/weather/history` | `city`, `limit` | 获取历史天气记录 |
| GET | `/api/weather/ping` | - | 健康检查 |

### ESP32 Web 服务 API

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/` | 控制面板首页 |
| GET | `/led/on` | 打开 LED |
| GET | `/led/off` | 关闭 LED |
| GET | `/led/status` | 查询 LED 状态 |
| GET | `/weather` | 获取天气 JSON |
| GET | `/setCity?city=xxx` | 切换城市 |

## ⚠️ 常见问题

### 1. 和风天气 API 返回 403
→ 检查 `application.yml` 中的 `api-key` 是否正确。免费订阅需使用 `devapi.qweather.com`。

### 2. ESP32 无法连接后端
→ 检查：
- ESP32 和电脑是否在同一 WiFi 下
- `backendHost` 是否填了电脑的正确局域网 IP
- 电脑防火墙是否开放了 8080 端口

### 3. OLED 不显示
→ 检查 I2C 地址：运行 I2C Scanner 确认地址是 `0x3C` 还是 `0x3D`。

### 4. MySQL 连接失败
→ 检查 MySQL 服务是否启动，用户名密码是否正确。

## 🔧 技术栈

- **硬件**: ESP32 + OLED (SSD1306) + LED
- **嵌入式**: Arduino C++ / WiFi / WebServer / HTTPClient
- **后端**: SpringBoot 2.7 + MyBatis-Plus + MySQL
- **构建**: Maven
- **天气数据**: 和风天气 API (QWeather)
